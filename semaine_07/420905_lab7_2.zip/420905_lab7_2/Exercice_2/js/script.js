//region Variables globales et constante (à consulter uniquement)
let gTableauPersonnages = ["pikachu"];
//endregion


//region TODO 01 : fonction init() - NE RIEN MODIFIER, SEULEMENT REGARDER
/**
 * Description : Cette fonction prépare la page
 */
function init() {
    document.getElementById("popcorn").addEventListener("click", enleverDernierTextePersonnage);
    document.getElementById("fantomas").addEventListener("click", ajouterTextePersonnage);
    document.getElementById("pikachu").addEventListener("click", ajouterTextePersonnage);
    document.getElementById("frankie").addEventListener("click", ajouterTextePersonnage);
    afficherTableau();
}
//endregion


//region TODO 02 : fonction enleverDernierTextePersonnage()
/**
 * Description : Permet d'effacer le dernier mot du tableau
 *
 * Algorithme : 1. Enlever le dernier élément du tableau des personnages
 *				2. Appeler la fonction pour afficher le tableau sur la scène
 */
function enleverDernierTextePersonnage() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region CODE À NE PAS MODIFIER

function afficherTableau() {
    document.getElementById("texteHalloween").textContent = "";
    for (var index = 0; index < gTableauPersonnages.length; index++) {
        document.getElementById("texteHalloween").textContent += " " + gTableauPersonnages[index];
    }
}

function ajouterTextePersonnage() {
    gTableauPersonnages.push(this.id);
    afficherTableau();
}
//endregion