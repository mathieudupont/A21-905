// VARIABLES GLOBALES
let gPlanificateur;  // Nombre entier avec le id de la tâche récurrente


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    document.getElementById("jouer").addEventListener("click", jouer);
    document.getElementById("boo").addEventListener("mouseover", gagner);
}


/* TODO 2
*  À faire :
*  1 - Créer un planificateur qui appelle la fonction bougerBoo
*      toutes les 1000 millisecondes et le mettre dans la variable
*      gPlanificateur.
*  2 - Appeler la fonction changerDisplay() en lui passant en paramètres :
*      la chaîne de caractères "jouer" et la chaîne de caractères "none".
*  3 - Appelez la fonction changerDisplay() en lui passant en paramètres :
*      la chaîne de caractères "bravo" et la chaîne de caractères "none".
*/
function jouer(){

    // ECRIRE DU CODE ICI




}


/* TODO 3
*  À faire :
*  1 - Appeler la fonction changerPositionAleatoirement. Elle ne prend aucun paramètre.
*  2 - Créer un planificateur qui appelle la fonction afficherBoo
*      seulement une fois dans 250 millisecondes.
*  3 - Créer un planificateur qui appelle la fonction cacherBoo
*      seulement une fois dans 500 millisecondes.
*/
function bougerBoo(){

    // ECRIRE DU CODE ICI




}


/* TODO 4
*  À faire :
*  1 - Mettre fin au planificateur se trouvant dans la variable gPlanificateur.
*  2 - Appeler la fonction cacherBoo. Elle ne prend aucun paramètre.
*  3 - Appeler la fonction changerDisplay() en lui passant en paramètres :
*      la chaîne de caractères "jouer" et la chaîne de caractères "block".
*  4 - Appeler la fonction changerDisplay() en lui passant en paramètres :
*      la chaîne de caractères "bravo" et la chaîne de caractères "block".
*/
function gagner(){

    // ECRIRE DU CODE ICI




}



//region NE PAS MODIFIER LE CODE À PARTIR D'ICI

function changerDisplay(id, valeur){
    document.getElementById(id).style.display = valeur;
}

function afficherBoo(){
    document.getElementById("boo").style.display = "block";
}

function cacherBoo(){
    document.getElementById("boo").style.display = "none";
}

function changerPositionAleatoirement(){
    let x = Math.ceil(Math.random() * 730); // Nombre aléatoire entre 1 et 730
    let y = Math.ceil(Math.random() * 380); // Nombre aléatoire entre 1 et 380
    document.getElementById("boo").style.left = x + "px";
    document.getElementById("boo").style.top = y + "px";
}
//endregion