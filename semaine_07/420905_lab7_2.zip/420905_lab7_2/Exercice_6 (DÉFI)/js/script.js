//DÉCLARATION DES VARIABLES GLOBALES (ACCESSIBLES PARTOUT)
let gIndexMusiqueCourante = 0; // L'index représentant la musique courante (au départ, la première du tableau)

let gTableauMusiques = ["Imagine Dragons - Birds - 3:42", "Tones and I - Dance Monkey - 3:56", "Maître Gims & Sting - Reste - 3:42",
                        "Vitaa & Slimane - Ça va ça vient - 3:33", "Sia - Unstoppable - 3:41", "Bigflo & Oli - Dommage - 3:23",
                        "Sinik - Le Réveil - 4:12", "Billie Eilish - bad guy - 3:26", "Bleu Jeans Bleu - Coton ouaté - 2:47",
                        "Céline Dion - Imperfections - 3:56"];

let gTableauIdsTitre = ["Dommage", "Le Réveil", "bad guy", "Coton ouaté", "Imperfections"];

/* Dans cet exercice, on compare deux façons de faire :
    Les cinq premières chansons ont des ids génériques : titre0, titre1, titre2, ...
    Les cinq dernières chansons ont des ids spécifiques : Dommage, Le réveil, bad guy, ...

    Voyons l'impact sur le code !
 */

//region TODO 01 : fonction init()
/**
 * Description : Ajouter des propriétés aux chansons de deux façons différentes
 *
 *  Algorithme : 1. Créer une boucle allant de 0 à 5 exclusivement
 *                      2. Ajouter un écouteur "click" qui appelle la fonction musiqueSelectionnee aux éléments ayant le id
 *                          "titre0", "titre1", "titre2", "titre3" et "titre4"
 *                      3. Ajouter la classe "rose" aux éléments ayant le id
 *                          "titre0", "titre1", "titre2", "titre3" et "titre4"
 *                      4. Déclarer une variable appelée musiqueCourante et l'instancier avec la valeur dans le tableau
 *                          des musiques à l'index courant de la boucle
 *                      5. Modifier le contenu textuel afin d'afficher la variable musiqueCourante. Ce changement est appliqué
 *                          aux éléments ayant le id "titre0", "titre1", "titre2", "titre3" et "titre4"
 *               (fin de la boucle)
 *
 *               6. Créer une boucle allant de 0 à la longueur du tableau des ids des titres
 *                      7. Déclarer une variable appelée idCourant et l'instancier avec la valeur dans le tableau
 *                          des ids des titres à l'index courant de la boucle
 *                      8. Ajouter un écouteur "click" qui appelle la fonction musiqueSelectionnee aux éléments dont le id est
 *                          représenté par la variable idCourant
 *                      9. Ajouter la classe "mauve" aux éléments dont le id est représenté par la variable idCourant
 *                      10. Modifier le contenu textuel des éléments dont le id est représenté par la variable idCourant
 *                          Le nouveau texte affiché sera l'élément dans le tableau des musiques à l'index courant de la boucle + 5
 *               (fin de la boucle)
 */
function init() {
    //Ne pas toucher à ce code
    document.getElementById("flecheDroite").addEventListener("click", musiqueSuivante);
    document.getElementById("flecheGauche").addEventListener("click", musiquePrecedente);
    document.getElementById("aleatoire").addEventListener("click", musiqueAleatoire);

    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 02 : fonction afficherMusiqueCourante()
/**
 * Description : Permet d'afficher la musique qui joue présentement
 *
 * Algorithme : 1. Déclarer une variable nommée "musiqueCourante" et l'instancier avec la valeur dans le tableau des musiques à l'index courant
 *                      Attention : comme nous sommes hors d'une boucle, l'index courant est une variable globale
 *		        2. Modifier le texte de l'élément avec le id "titreCourant" pour la valeur de la variable musiqueCourante
 */
function afficherMusiqueCourante() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 03 : fonction musiqueSuivante()
/**
 * Description : Va chercher la prochaine musique dans la liste
 *
 * Algorithme : 1. Augmenter de 1 l'index de musique courante
 *		        2. Si l'index de musique courante est supérieur ou égale à la longueur du tableau de musique
 *			            3. Mettre l'index de musique courante à 0
 *		        4. Appeler la fonction pour afficher la musique courante
 */
function musiqueSuivante() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 04 : fonction musiquePrecedente()
/**
 * Description : Va chercher la musique précédente dans la liste
 *
 * Algorithme : 1. Réduire de 1 l'index de musique courante
 *		        2. Si l'index de musique courante est inférieur à 0
 *			            3. Mettre l'index de musique courante à la longueur du tableau -1
 *		        4. Appeler la fonction pour afficher la musique courante
 */
function musiquePrecedente() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 05 : fonction musiqueSelectionnee(evt)
/**
 * Description : Obtient la musique sur laquelle on a cliqué et la met comme musique courante
 *
 * Algorithme : 1. Basculer la classe "coloré" sur l'élément ciblé
 *		        2. Déclarer une variable appelée indexMusique et l'instancier avec l'attribut "title" de l'élément ciblé
 *		        3. Mettre dans la variable gIndexMusiqueCourante la valeur de la variable indexMusique
 *		        4. Appeler la fonction afficherMusiqueCourante
 */
function musiqueSelectionnee() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region CODE À NE PAS MODIFIER

/**
 * Description : Permet de choisir une musique de façon aléatoire
 */
function musiqueAleatoire() {
    gIndexMusiqueCourante = Math.floor(Math.random() * gTableauMusiques.length);
    afficherMusiqueCourante();
}

//endregion