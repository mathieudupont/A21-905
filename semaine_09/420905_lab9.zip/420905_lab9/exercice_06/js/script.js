// VARIABLES GLOBALES

let gX = 720; // Position horizontale de Mario
let gY = 380; // Position verticale de Mario

// Tableaux de coordonnées pour les voitures
gVoituresX = [];
gVoituresY = [];


/* TODO 1
*  À faire :
*  1 - Créer un écouteur d'événement clavier qui appelle la fonction bougerMario.
*/
function init(){

    // ECRIRE DU CODE ICI





    // NE PAS TOUCHER AU CODE CI-DESSOUS
    for(let index = 1; index < 8; index++){
        gVoituresX.push(parseInt(document.getElementById("voiture" + index).style.left));
        gVoituresY.push(parseInt(document.getElementById("voiture" + index).style.top));
    }

}


/* TODO 2
*  À faire :
*  1 - Déclarer une variable nommée touche et l'instancier avec 
*      la valeur de la touche appuyée.
*
*  2 - Si la touche est égale à "ArrowUp"
*  3 -      Réduire la valeur de la variable gY de 5.
*
*  4 - Si la touche est égale à "ArrowDown"
*  5 -      Augmenter la valeur de la variable gY de 5.
*
*  6 - Si la touche est égale à "ArrowLeft"
*  7 -      Réduire la valeur de la variable gX de 5.
*
*  8 - Si la touche est égale à "ArrowRight"
*  9 -      Augmenter la valeur de la variable gX de 5.
*
* 10 - Appeler la fonction mettreMarioAJour. Elle ne prend aucun paramètre.
*/
function bougerMario(evenement){

    // ECRIRE DU CODE ICI




}


//region NE PAS TOUCHER AU CODE À PARTIR D'ICI

function mettreMarioAJour(){
    gX = gX < 0 ? 0 : (gX > 720 ? 720 : gX);
    gY = gY < 0 ? 0 : (gY > 380 ? 380 : gY);

    document.getElementById("mario").style.left = gX + "px";
    document.getElementById("mario").style.top = gY + "px";

    for(let index = 1 ; index < 8; index++){
        if(gX < gVoituresX[index] + 90 && gX + 64 > gVoituresX[index] &&
           gY < gVoituresY[index] + 54 && gY + 64 > gVoituresY[index]){
                document.getElementById("perdu").style.display = "block";
        }
    }

    if(gX < 10 + 31 && gX + 64  > 10 && gY < 10 + 54 && gY > 10){
        document.getElementById("bravo").style.display = "block";
    }
}
//endregion