// VARIABLES GLOBALES (Aucune)


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    document.getElementById("boutonBebe").addEventListener("click", afficherAge);
    document.getElementById("boutonLettre").addEventListener("click", afficherDestinaire);
    document.getElementById("boutonLivre").addEventListener("click", afficherNbPages);
    document.getElementById("boutonVase").addEventListener("click", afficherPrix);
}


/* TODO 2
*  À faire :
*  1 - Déclarer la variable age et l'instancier avec la valeur de 
*      l'attribut "data-age" de l'élément avec l'id "bebe"
*  2 - Mettre dans le contenu textuel de l'élément avec l'id "ageBebe"
*      la valeur de la variable age
*/
function afficherAge(){

    // ECRIRE DU CODE ICI




}


/* TODO 3
*  À faire :
*  1 - Déclarer la variable destinataire et l'instancier avec la valeur de 
*      l'attribut "data-destinataire" de l'élément avec l'id "lettre"
*  2 - Mettre dans le contenu textuel de l'élément avec l'id "destinataireLettre"
*      la valeur de la variable destinataire
*/
function afficherDestinaire(){

    // ECRIRE DU CODE ICI




}


/* TODO 4
*  À faire :
*  1 - Déclarer la variable nbPages et l'instancier avec la valeur de 
*      l'attribut "data-nbPages" de l'élément avec l'id "livre"
*  2 - Mettre dans le contenu textuel de l'élément avec l'id "nbPagesLivre"
*      la valeur de la variable nbPages
*/
function afficherNbPages(){

    // ECRIRE DU CODE ICI




}



/* TODO 5
*  À faire :
*  1 - Déclarer la variable prix et l'instancier avec la valeur de 
*      l'attribut "data-prix" de l'élément avec l'id "vase"
*  2 - Mettre dans le contenu textuel de l'élément avec l'id "prixVase"
*      la valeur de la variable prix
*/
function afficherPrix(){

    // ECRIRE DU CODE ICI




}