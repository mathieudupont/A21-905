
/* TODO 1
*  Variables globales.
*
*  À faire :
*   1 - Déclarer une variable de type CONSTANTE nommée NOTE_DE_PASSAGE et lui affecter la valeur 60
*/

// ECRIRE DU CODE ICI


// NE PAS TOUCHER À CES LIGNES DE CODE :
let gTableauCours = ['Prog', 'C. Web', 'Img Mat.', 'Philo', 'Français', 'Anglais'] ;
let gTableauNotes = [0, 0, 0, 0, 0, 0] ;


/* TODO 2
*  init() : Déclaration des évènements nécessaires.
*  IL N'Y A RIEN À AJOUTER. À consulter seulement.
*/
function init(){
    // NE PAS TOUCHER À CES LIGNES DE CODE :
    for (let index = 0 ; index < gTableauNotes.length ; index++) {
        gTableauNotes[index] = 50 + Math.floor(Math.random() * 51);
    }
    document.getElementById("bouton1").addEventListener("click", verifierCours);
    afficherTableaux() ;
}


/* TODO 3
*  verifierCours() : Détermine les cours réussis et les cours échoués et affiche les résultats.
*
*  À faire :
*   1 - Déclarer une variable nommée nbCoursReussis et lui affecter la valeur 0
*   2 - Déclarer une variable nommée coursReussis et lui affecter la valeur ""
*   3 - Déclarer une variable nommée nbCoursEchoues et lui affecter la valeur 0
*   4 - Déclarer une variable nommée coursEchoues et lui affecter la valeur ""
*
*   5 - Créer une boucle où l'index prend les valeurs de 0 jusqu'à la taille de gTableauNotes moins un.
*       À l'intérieur de la boucle :
*   6 -     Si la valeur dans la cellule [index] de gTableauNotes est supérieure ou égale à NOTE_DE_PASSAGE
*   7 -         Incrémenter de 1 la valeur de la variable nbCoursReussis
*   8 -         Concaténer à la variable coursReussis la valeur dans la cellule [index] de gTableauCours et ", "
*   9 -     Sinon
*   10 -         Incrémenter de 1 la valeur de la variable nbCoursEchoues
*   11 -         Concaténer à la variable coursEchoues la valeur dans la cellule [index] de gTableauCours et ", "
*       (fin de la boucle)
*
*   12 - Affecter au context textuel de l'élément avec l'ID 'resultat1' la valeur dans la variable nbCoursReussis
*   13 - Affecter au context textuel de l'élément avec l'ID 'resultat2' la valeur dans la variable coursReussis
*   14 - Affecter au context textuel de l'élément avec l'ID 'resultat3' la valeur dans la variable nbCoursEchoues
*   15 - Affecter au context textuel de l'élément avec l'ID 'resultat4' la valeur dans la variable coursEchoues
*
*   ATTENTION : il faut utiliser .length
*/
function verifierCours(){

    // ECRIRE DU CODE ICI


}


// NE PLUS TOUCHER AU CODE À PARTIR D'ICI

function afficherTableaux(){

    let texte = '<tr><td class="index" style="width: 160px; background: black; box-shadow: none;">index</td>';
    for (let i = 0 ; i < gTableauCours.length ; i++){
        texte += '<td class="index">' + i + '</td>';
    }
    texte += '</tr>';

    tableaux = [gTableauCours, gTableauNotes];
    tableauxNoms = ['gTableauCours', 'gTableauNotes'];
    for (let i = 0 ; i < 2 ; i++){
        texte += '<tr><td class="zone" style="font-size: 24px; width: 160px; color: white; background: black; box-shadow: none;">' + tableauxNoms[i] + '</td>';
        for (let j = 0 ; j < tableaux[i].length ; j++){
            texte += '<td class="zone">' + tableaux[i][j] + '</td>';
        }
        texte += '</tr>';
    }

    document.getElementById('tableau').innerHTML = texte;
}