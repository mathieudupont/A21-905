
/**
 * Cet exercice est identique au précédent, à l'exception que le code sera beaucoup simplifié
 * grâce à l'utilisation du mot-clé this
 */

//region TODO 01 : Regarder la fonction init (CONSULTATION SEULEMENT)
/**
 * Fonction principale de l'application.
 * Elle est appelée immédiatement après la fin du chargement du document HTML.
 */
function init() {
    // RIEN NE DOIT ÊTRE MODIFIÉ DANS CETTE FONCTION, VOUS POUVEZ PASSER AU TODO SUIVANT
    // Lier les évènements souhaités des objets aux fonctions a exécuter
    // À remarquer : une seule et même fonction, ajouterMot, est appelée pour les 4 mots :
    document.getElementById("mot1").addEventListener("mouseover", ajouterMot);
    document.getElementById("mot2").addEventListener("mouseover", ajouterMot);
    document.getElementById("mot3").addEventListener("mouseover", ajouterMot);
    document.getElementById("mot4").addEventListener("mouseover", ajouterMot);
}
//endregion


//region TODO 02 : Compléter la fonction ajouterMot()
/**
 * Description : Cette fonction s'exécute suite à un événement 'mouseover'.
 *
 * Algorithme :
 *
 *      1. Ajouter à la phrase le texte du mot
 *      2. Rendre le mot invisible
 *
 *  Différence avec l'exercice précédent :
 *  1. Au lieu de 4 fonctions différentes, une seule fonction sert pour tous les mots.
 *  2. Utilisation du mot-clé this : il suffit, par exemple, de remplacer :
 *          document.getElementById("mot1")
 *      par :
 *          this
 */
function ajouterMot() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion
