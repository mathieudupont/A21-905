/* Mise en situation
* Meta (anciennement Facebook) demande à avoir une interface pour que les usagers puissent acheter des
* MetaCoins dans leur univers en ligne. On peut augmenter ou réduire le nombre de pièces de monnaie.
* Chaque fois que l'on fait cela, on modifie le texte affiché.
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : augmenter */
function augmenter(){



    // ECRIRE DU CODE ICI



}

/* TODO 3 : reduire */
function reduire(){



    // ECRIRE DU CODE ICI



}


