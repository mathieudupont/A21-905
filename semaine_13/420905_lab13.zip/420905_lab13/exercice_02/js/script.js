/* Mise en situation
 * Netflix vous contacte pour faire une publicité pour Squid Game.
 * Le jeu est simple : quand on clique sur le bouton rouge, on affiche l'image qui dit de ne pas bouger.
 * Quand on clique sur le bouton vert, on affiche l'image qui dit d'avancer.
 * Les images sont dans le dossier images.
 */

// VARIABLES GLOBALES


/* TODO 1 : init */
function init(){


    // ECRIRE DU CODE ICI



}

/* TODO 2 : clicO */
function clicO(){



    // ECRIRE DU CODE ICI



}

/* TODO 3 : clicX */
function clicX(){



    // ECRIRE DU CODE ICI



}