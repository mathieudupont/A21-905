/*  TODO 1
*   init() : Déclaration des 3 événements pour les boutons
*    IL N'Y A RIEN À MODIFIER CI-DESSOUS. JUSTE REGARDER.
*/
function init(){
    // Bouton 1
    document.getElementById("bouton1").addEventListener("click", ajouterRouge);

    // Bouton 2
    document.getElementById("bouton2").addEventListener("click", retirerRouge);

    // Bouton 3
    document.getElementById("bouton3").addEventListener("click", changerStyle);
}

/*  TODO 2
*   ajouterRouge() : Ajoute la classe "rouge" à toutes les images de la page
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index dépasse 9
*       et qui augmente de 1 à chaque itération.
*   2 - Dans la boucle, ajouter la classe "rouge" à tous les éléments avec
*       l'id #meme1, #meme2, #meme3, ..., jusqu'à #meme9. Attention, il n'y a
*       qu'un seule ligne de code dans la boucle, mais c'est grâce aux itérations
*       qu'on applique la classe à tous les éléments.
*/
function ajouterRouge(){
    // Ajoutez votre code ici
}

/*  TODO 3
*   retirerRouge() : Retirer la classe "rouge" à toutes les images de la page
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index dépasse 9
*       et qui augmente de 1 à chaque itération.
*   2 - Dans la boucle, retirer la classe "rouge" à tous les éléments avec
*       l'id #meme1, #meme2, #meme3, ..., jusqu'à #meme9. Attention, il n'y a
*       qu'un seule ligne de code dans la boucle, mais c'est grâce aux itérations
*       qu'on retire la classe à tous les éléments.
*/
function retirerRouge(){
    // Ajoutez votre code ici
}

/*  TODO 4
*   changerStyle() : Ajoute / retire un style à toutes les images de la page
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index dépasse 9
*       et qui augmente de 1 à chaque itération.
*   Dans la boucle, ajouter un if...else :
*   2 - Si l'élément #meme1 (ou #meme2, etc.) possède la valeur "" pour leur attribut "style" (getAttribute)
*   3 -     Attribuer la valeur "border-color:gold;" à l'attribut "style". (setAttribute)
*   4 - Sinon
*   5 -     Attribuer la valeur "" (chaîne vide) à l'attribut "style". (setAttribute)
*/
function changerStyle(){
    // Ajoutez votre code ici
}