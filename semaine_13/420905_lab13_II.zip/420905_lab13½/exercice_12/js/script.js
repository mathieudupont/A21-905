/*  Exercice 12 :
    Lorsqu'on survole un Pokémon, son image obtient la classe "ombre".
    Lorsqu'on arrête de le survoler, son image perd la classe "ombre".
    Rappel des types d'événements qu'on a vu : click, mouseover, mouseout, keydown.
*/

/* TODO 1 : init */
function init(){


}

/* TODO 2 : ajouterClasseOmbre */
function ajouterClasseOmbre(){


}

/* TODO 3 : retirerClasseOmbre */
function retirerClasseOmbre(){


}
