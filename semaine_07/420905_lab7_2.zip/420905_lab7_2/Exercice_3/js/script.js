//region Variables globales et constante (à consulter uniquement)
let gTableauIdsPersonnages = ["fantomas", "pikachu", "frankie"];
let gTableauPersonnages = ["pikachu"];
//endregion


//region TODO 01 : fonction init()
/**
 *  Description : Ajoute tous les écouteurs aux images de la page
 *
 *  Algorithme : 1. Créer une boucle qui parcourt tout le tableau des ids des personnages
 *  					2. Déclarer une variable appelée idCourant et l'instancier avec l'élément dans le tableau
 *  						des ids des personnages à l'index courant de la boucle
 *  					3. Ajouter un écouteur "click" qui appelle la fonction ajouterTextePersonnage pour l'élément
 *  				    	dont le id est représenté par la variable idCourant
 *  		     (fin de la boucle)
 *
 *               4. Appeler la fonction pour afficher le tableau
 */
function init() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion



//region CODE À NE PAS MODIFIER

function afficherTableau() {
    document.getElementById("texteHalloween").textContent = "";
    for (var index = 0; index < gTableauPersonnages.length; index++) {
        document.getElementById("texteHalloween").textContent += " " + gTableauPersonnages[index];
    }
}

function ajouterTextePersonnage() {
    gTableauPersonnages.push(this.id);
    afficherTableau();
}
//endregion