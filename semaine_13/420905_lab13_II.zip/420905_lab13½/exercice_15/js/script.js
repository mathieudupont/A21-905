/* Exercice 15
   Les deux boutons ci-dessous permettent d'afficher un message différent. Le
   bouton bleu permet d'afficher un message composé de tous les mots à un index
   impair du tableau, (1,3,5,7,9,..) alors que le bouton rouge permet d'afficher
   un message composé de tous les mots à un index pair (0,2,4,6,8,...) du tableau.

   N'oubliez pas de vider le message avant d'en afficher un nouveau !
   (Donc mettre le textContent = "")
*/

// VARIABLES GLOBALES
let gTableauDeMots = ["J'adore ", "Chaque ", "vraiment ", "jour ", "faire ", "passé ", "de ", "à ", "la ",
    "cette ", "programmation ", "école ", "à ", "est ", "mon ", "un ", "cégep.", "supplice."];

/* TODO 1 : init */
function init(){

    
}

/* TODO 2 : afficherMessageImpair */
function afficherMessageImpair(){


}

/* TODO 3 : afficherMessagePair */
function afficherMessagePair(){


}
