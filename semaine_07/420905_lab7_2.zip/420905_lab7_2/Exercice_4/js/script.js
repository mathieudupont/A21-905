let gTableauIdsPersonnages = ["jonesy", "hawk", "headhunter", "banshee",
							"ramirez", "renegade", "splitfire", "wildcat"];

//region TODO 01 : fonction init
/**
 *  Description : Ajoute tous les personnages du tableau sur la page
 *
 *  Algorithme : 1. Créer une boucle qui parcourt tout le tableau des ids des personnages
 *  					2. Déclarer une variable appelée idCourant et l'instancier avec l'élément dans le tableau
 *  						des ids des personnages à l'index courant de la boucle
 *  					3. Déclarer une variable appelée sourceImage et l'instancier avec la chaîne de caractères suivante :
 *  							"images/[id].png" où [id] est la variable idCourant
 *  					4. Modifier l'attribut "src" de l'élément dont le id est représenté par la variable idCourant
 *  						pour la valeur de la variable sourceImage
 *
 */
function init() {
	// Écrire le code ci-dessous


	// ECRIRE DU CODE ICI


}
//endregion