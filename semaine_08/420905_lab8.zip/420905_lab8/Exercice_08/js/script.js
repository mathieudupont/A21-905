
/* TODO 1 : Déclarer les variables globales
    À faire :
        1 - Déclarer la variable globale gIdAmpoules1 et l'instancier à un tableau vide
        2 - Déclarer la variable globale gIdAmpoules2 et l'instancier à un tableau vide
*/


// ECRIRE DU CODE ICI




/* TODO 2 : fonction init
    À faire :
        1 - Dans une boucle, pour les valeurs 0 à 4 d'une variable index,
        2 -     Créer un écouteur d'évènement "click" sur l'élément avec l'ID "ampoule[index]"
                qui appellera la fonction switch0
        3 -     Ajouter la chaîne de caractères "ampoule[index]" au tableau gIdAmpoules1
            (fin de la boucle)
        4 - Dans une boucle, pour les valeurs 5 à 12 d'une variable index,
        5 -     Créer un écouteur d'évènement "click" sur l'élément avec l'ID "ampoule[index]"
                qui appellera la fonction switch0
        6 -     Ajouter la chaîne de caractères "ampoule[index]" au tableau gIdAmpoules2
            (fin de la boucle)
        7 - Créer un écouteur d'évènement "click" sur l'élément avec l'ID "on1" qui appellera la fonction on1
        8 - Créer un écouteur d'évènement "click" sur l'élément avec l'ID "switch1" qui appellera la fonction switch1
        9 - Créer un écouteur d'évènement "click" sur l'élément avec l'ID "off1" qui appellera la fonction off1
        10- Créer un écouteur d'évènement "click" sur l'élément avec l'ID "on2" qui appellera la fonction on2
        11- Créer un écouteur d'évènement "click" sur l'élément avec l'ID "switch2" qui appellera la fonction switch2
        12- Créer un écouteur d'évènement "click" sur l'élément avec l'ID "off2" qui appellera la fonction off2
*/
function init() {


// ECRIRE DU CODE ICI


}


/* TODO 3 : fonction switchAmpoule
    À faire :
        1 - Déclarer une variable nommée element et lui affecter l'élément avec l'ID idAmpoule
        2 - Si la valeur de l'attribut "src" de l'élément element est "img/lightOff.png"
        3 -     Modifier la valeur de l'attribut "src" de l'élément element pour "img/lightOn.png"
        4 - Sinon
        5 -     Modifier la valeur de l'attribut "src" de l'élément element pour "img/lightOff.png"
 */
function switchAmpoule(idAmpoule) {


// ECRIRE DU CODE ICI


}


/* TODO 4 : fonction switch0
    À faire :
        1 - Déclarer une variable idAmpoule et lui affecter la valeur de l'attribut "id" de l'élément ciblé
        2 - Appeler la fonction switchAmpoule en lui passant comme paramètre idAmpoule
 */
function switch0() {


// ECRIRE DU CODE ICI


}


/* TODO 5 : fonction switch1
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules1,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules1 à la position index
        3 -     Appeler la fonction switchAmpoule en lui passant comme paramètre idAmpoule
            (fin de la boucle)
 */
function switch1() {


// ECRIRE DU CODE ICI


}


/* TODO 6 : fonction switch2
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules2,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules2 à la position index
        3 -     Appeler la fonction switchAmpoule en lui passant comme paramètre idAmpoule
            (fin de la boucle)
 */
function switch2() {


// ECRIRE DU CODE ICI


}


/* TODO 7 : fonction allumerOuEteindreAmpoule
    À faire :
        1 - Modifier la valeur de l'attribut "src" de l'élément avec l'ID idAmpoule pour la valeur de source
 */
function allumerOuEteindreAmpoule(idAmpoule, source) {


// ECRIRE DU CODE ICI


}


/* TODO 8 : fonction on1
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules1,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules1 à la position index
        3 -     Appeler la fonction allumerOuEteindreAmpoule en lui passant comme paramètres
                la variable idAmpoule et la chaîne de caractères "img/lightOn.png"
            (fin de la boucle)
 */
function on1() {


// ECRIRE DU CODE ICI


}


/* TODO 9 : fonction off1
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules1,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules1 à la position index
        3 -     Appeler la fonction allumerOuEteindreAmpoule en lui passant comme paramètres
                la variable idAmpoule et la chaîne de caractères "img/lightOff.png"
            (fin de la boucle)
 */
function off1() {


// ECRIRE DU CODE ICI


}


/* TODO 10 : fonction on2
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules2,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules2 à la position index
        3 -     Appeler la fonction allumerOuEteindreAmpoule en lui passant comme paramètres
                la variable idAmpoule et la chaîne de caractères "img/lightOn.png"
            (fin de la boucle)
 */
function on2() {


// ECRIRE DU CODE ICI


}


/* TODO 11 : fonction off2
    À faire :
        1 - Dans une boucle, pour une variable index qui parcourt tous les indices du tableau gIdAmpoules2,
        2 -     Déclarer une variable idAmpoule et lui affecter
                l'ID situé dans le tableau gIdAmpoules2 à la position index
        3 -     Appeler la fonction allumerOuEteindreAmpoule en lui passant comme paramètres
                la variable idAmpoule et la chaîne de caractères "img/lightOff.png"
            (fin de la boucle)
 */
function off2() {


// ECRIRE DU CODE ICI


}