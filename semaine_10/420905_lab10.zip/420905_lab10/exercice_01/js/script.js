// VARIABLES GLOBALES
let gTableauImages = ["pomme", "banane", "cerise", "orange", "raisin"];

/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    document.getElementById("bouton1").addEventListener("click", bouton1);
    document.getElementById("bouton2").addEventListener("click", bouton2);
    document.getElementById("bouton3").addEventListener("click", bouton3);
    document.getElementById("bouton4").addEventListener("click", bouton4);
    document.getElementById("reset").addEventListener("click", reinitialiserTableau);
    afficherImages();
}

/* TODO 2
*  À faire :
*  1 - Retirer la cerise, l'orange et le raisin du tableau d'images.
*  2 - Appeler la fonction affichageAJour().
 */
function bouton1(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 3
*  À faire :
*  1 - Retirer la pomme du tableau d'images.
*  2 - Appeler la fonction affichageAJour().
 */
function bouton2(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 4
*  À faire :
*  1 - Ajouter "melon", "aubergine" et "ananas" dans le tableau
*      d'images entre la banane et la cerise.
*  2 - Appeler la fonction affichageAJour();
 */
function bouton3(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 5
*  À faire :
*  1 - Ajouter "fraise" et "citron" avant la pomme dans le tableau d'images.
*  2 - Appeler la fonction affichageAJour();
 */
function bouton4(){

    // ÉCRIRE VOTRE CODE ICI

}

// Ne pas modifier le code à partir d'ici

function reinitialiserTableau(){
    gTableauImages = ["pomme", "banane", "cerise", "orange", "raisin"];
    afficherImages();
    displayBouton("block");
    document.getElementById("reset").style.display = "none";
}

function affichageAJour(){
    displayBouton("none");
    document.getElementById("reset").style.display = "block";
    afficherImages();
}

function afficherImages(){
    for(let index = 0; index < 8; index++){
        if(index < gTableauImages.length){
            document.getElementById("fruit" + (index + 1)).style.display = "block";
            document.getElementById("fruit" + (index + 1)).setAttribute("src", "images/" + gTableauImages[index] + ".png");
        }
        else{
            document.getElementById("fruit" + (index + 1)).style.display = "none";
        }

    }
}

function displayBouton(valeur){
    for(let index = 1; index < 5; index++){
        document.getElementById("bouton"+index).style.display = valeur;
    }
}