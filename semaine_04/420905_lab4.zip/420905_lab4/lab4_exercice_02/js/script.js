// VARIABLE GLOBALE
let gCompteur = 0; // Représente la valeur actuelle du compteur


/*  TODO 1
*   init() : Déclaration des 4 événements nécessaires.
*   IL N'Y A RIEN À MODIFIER DANS CETTE FONCTION, JUSTE REGARDER.
*/
function init(){
    // Les deux flèches vertes appellent la fonction compteurPlus() lorsque cliquées
    document.getElementById("plus").addEventListener('click', compteurPlus);
    document.getElementById("plus2").addEventListener('click', compteurPlus);

    // Les deux flèches rouges appellent la fonction compteurMoins() lorsque cliquées
    document.getElementById("moins").addEventListener('click', compteurMoins);
    document.getElementById("moins2").addEventListener('click', compteurMoins);
}

/* TODO 2
*  compteurPlus() : Augmente la valeur du compteur de 1 ou 2
*
*  À faire :
*  → Retirer l'instruction gCompteur = gCompteur + 1;
*  Créer un if()...else :
*  1 -  Si l'élément ciblé (this) contient la classe "super" (classList.contains)
*  2 -      On augmente le compteur de 2
*  3 -  Sinon
*  4 -      On augmente le compteur de 1
*
*  → this représente la flèche qui vient d'être cliquée. Ça veut dire que ça peut être
*    la flèche simple ou la flèche double. (Seule la flèche double possède la classe "super")
*/
function compteurPlus(){
    gCompteur = gCompteur + 1;

    // Créer un if...else ici !

    // On garde cette ligne de code pour afficher la nouvelle valeur
    document.getElementById("compteurId").textContent = gCompteur;
}

/* TODO 3
*  compteurMoins() : Réduit la valeur du compteur de 1 ou 2
*
*  À faire :
*  → Retirer l'instruction gCompteur = gCompteur - 1;
*  Créer un if()...else :
*  1 - Si l'élément ciblé (this) contient la classe "super" (classList.contains)
*  2 -     On réduit le compteur de 2
*  3 - Sinon
*  4 -     On réduit le compteur de 1
*
*  → this représente la flèche qui vient d'être cliquée. Ça veut dire que ça peut être
*    la flèche simple ou la flèche double. (Seule la flèche double possède la classe "super")
*/
function compteurMoins(){
    gCompteur = gCompteur - 1;

    // Créer un if...else ici !

    // On garde cette ligne de code pour afficher la nouvelle valeur
    document.getElementById("compteurId").textContent = gCompteur;
}
