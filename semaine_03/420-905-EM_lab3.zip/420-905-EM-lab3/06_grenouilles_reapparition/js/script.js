
//region TODO 01 : fonction sourisSurGrenouille()
/**
 * Description : Mettre la visibilité à 100% lorsque la souris survole une grenouille
 *
 * Algorithme : 1.   Mettre l'opacité de la grenouille cible à "1"
 *
 * Attention : Il faut utiliser le mot-clé this
 */
function sourisSurGrenouille() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region TODO 02 : fonction clickSurGrenouille()
/**
 * Description : Déplacer la grenouille cliquée aléatoirement sur la scène et
 *               mettre sa visibilité à 70%
 *
 * Algorithme (les points 1 et 2 sont déjà faits, mais vouz devez les décommenter pour qu'ils fonctionnent) :
 *              1.   Mettre la grenouille cible à une position aléatoire entre 0 et 200 px sur l'axe vertical
 *              2.   Mettre la grenouille cible à une position aléatoire entre 0 et 400 px sur l'axe horizontal
 *				3.   Mettre la visibilité de la grenouille cible à 70%
 *
 * Attention : Il faut utiliser le mot-clé this
 */
function clickSurGrenouille() {

    // DÉCOMMENTER CES 2 LIGNES :
    // this.style.top = genererNombreAleatoire(0, 200) + "px";
    // this.style.left = genererNombreAleatoire(0, 400) + "px";

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region TODO 03 : fonction sourisHorsGrenouille()
/**
 * Description : Mettre la visibilité à 70% lorsque la souris arrête de survoler la grenouille
 *
 * Algorithme : 1. Mettre l'opacité de la grenouille cible à "0.7"
 *
 * Attention : Il faut utiliser le mot-clé this
 */
function sourisHorsGrenouille() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region CODE À NE PAS MODIFIER
/**
 * Permet de générer un nombre entier alétoire compris entre deux valeurs inclusivement
 * @param {la valeur minimum possible pouvant être générée} min 
 * @param {la valeur maximum possible pouvant être générée} max 
 */
function genererNombreAleatoire(min, max) {
    return Math.floor(Math.random() * (+max - +min));
}

/**
 * Description : Permet d'ajouter une nouvelle grenouille à la scène
 */
function preparerUneGrenouille(pCouleur) {
    let grenouille = document.getElementById("grenouille" + pCouleur);
    grenouille.addEventListener('click', clickSurGrenouille);
    grenouille.addEventListener('mouseover', sourisSurGrenouille);
    grenouille.addEventListener('mouseout', sourisHorsGrenouille);
    grenouille.style.top = genererNombreAleatoire(0, 200) + "px";
    grenouille.style.left = genererNombreAleatoire(0, 400) + "px";
}

/**
 * Description : Création de grenouilles de départ sur la scène pour l'exercice.
 */
function preparationCanvasPourExercice() {
    preparerUneGrenouille("Bleue");
    preparerUneGrenouille("Mauve");
    preparerUneGrenouille("Orange");
    preparerUneGrenouille("Verte");
}

/**
 * Description : Cette fonction prépare la scène et les grenouilles à manipuler
 */
function init() {
    preparationCanvasPourExercice();
}
//endregion