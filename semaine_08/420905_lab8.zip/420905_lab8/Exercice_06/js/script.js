
/* TODO 1 : fonction init
    À faire :
        1 - Appeler la fonction creerGrenouille en lui passant 2 paramètres :
                - un nombre entier de votre choix entre 0 et 600 (pour la position horizontale de la grenouille)
                - un nombre entier de votre choix entre 0 et 600 (pour la position verticale de la grenouille)
*/
function init() {


// ECRIRE DU CODE ICI


}


/* TODO 2 : fonction creerGrenouille
    À faire :
        1 - Déclarer une variable nommée element et l'instancier avec l'élément avec l'ID "grenouille1"
        2 - Modifier la valeur de l'attribut "src" de l'élément element pour "img/grenouilleBleue.png"
        3 - Modifier la propriété de style left de l'élément element
            pour "[x]px" où [x] est la valeur du paramètre x
        4 - Modifier la propriété de style top de l'élément element
            pour "[y]px" où [y] est la valeur du paramètre y
 */
function creerGrenouille(x, y) {


// ECRIRE DU CODE ICI


}