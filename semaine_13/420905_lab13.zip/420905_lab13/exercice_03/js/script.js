/* Mise en situation
* Pendant que vous écoutiez Squid Game, vos moutons se sont faits mangés par des loups !
* Ainsi, chaque clic sur un mouton révélera le loup qui l'a mangé.
 */

// VARIABLES GLOBALES


/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : transformer */
function transformer(){



    // ECRIRE DU CODE ICI



}



