/*  Exercice 14
    Lorsqu'on clique sur un personnage, cela affiche ses informations
    en-dessous. (Nom et couleur préférée) Mais... où sont les données à afficher ?
*/

// VARIABLES GLOBALES

/* TODO 1 : init */
function init(){

    
}

/* TODO 2 : afficherInfo */
function afficherInfo(){


}
