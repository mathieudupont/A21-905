/* Mise en situation
* Mr.Beast a beaucoup aimé votre travail et il vous invitera à sa prochaine vidéo. En attendant, il voudrait que
* tous les mots impairs soient remplacés par "MR ". Attention, vous devez utiliser une condition, pas uniquement
* changer le texte "BEAST " par "MR BEAST ".
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : clicBouton */
function clicBouton(){



    // ECRIRE DU CODE ICI



}


