
/* TODO 1 : Rien à faire ici */
function init() {
    document.getElementById("bouton1").addEventListener('click', succes);
    document.getElementById("bouton2").addEventListener('click', echec);
    document.getElementById("bouton3").addEventListener('click', echec);
    document.getElementById("bouton4").addEventListener('click', echec);
}


/* TODO 2 : fonction afficherResultat
    À faire :
        1 - Remplacer le contenu textuel de l'élément avec l'ID "reponse" par la valeur de texteReponse
        2 - Modifier la couleur de fond de l'élément avec l'ID "reponse" pour la valeur de couleur
 */
function afficherResultat(texteReponse, couleur) {


// ECRIRE DU CODE ICI


}


/* TODO 3 : fonction echec
    À faire :
        1 - Appeler la fonction afficherResultat en lui passant comme paramètres
            les valeurs "Meilleure chance la prochaine fois!" et "red"
 */
function echec() {


// ECRIRE DU CODE ICI


}


/* TODO 4 : fonction succes
    À faire :
        1 - Appeler la fonction afficherResultat en lui passant comme paramètres
            les valeurs "Exact!" et "green"
 */
function succes() {


// ECRIRE DU CODE ICI


}