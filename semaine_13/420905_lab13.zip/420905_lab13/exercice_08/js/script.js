/* Mise en situation
* Mr.Beast a obtenu un sponsor de Raid: ShadowLegends et a maintenant les fonds pour améliorer son site.
* Il veut que lorsque le nombre de clic est entre 0 et 5, on affiche un grade vert.
* Un nombre de clic entre 6 et 10 est un grade jaune.
* Entre 11 et 19 est un grade orange.
* Et 20 et plus est un grade rouge.
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : clicBouton */
function clicBouton(){



    // ECRIRE DU CODE ICI



}


