
//region TODO 01 : Compléter la fonction eteindreLumiere()
/**
 * Description : Cette fonction s'exécute suite à un événement 'click' sur la lumière allumée.
 *
 * Algorithme :
 *
 *  Inscrire les intructions permettant de réaliser les actions suivantes (2 instructions):
 *
 *      1. Faire disparaître l'élément de lumière allumée
 *      2. Faire apparaître l'élément de lumière éteinte
 *		
 *	Pour vous aider :
 *      L'attribut de style à changer est display et ses valeurs sont "block" ou "none"
 */
function eteindreLumiere() {

    // ÉCRIRE VOTE CODE ICI
}
//endregion


//region TODO 02 : Compléter la fonction allumeLumiere()
/**
 * Description : Cette fonction s'exécute suite à un événement 'click' sur la lumière éteinte.
 *
 * Algorithme :
 *
 *  Inscrire les intructions permettant de réaliser les actions suivantes (2 instructions):
 *
 *      1. Faire disparaître l'élément de lumière éteinte
 *      2. Faire apparaître l'élément de lumière allumée
 */
function allumeLumiere() {

    // ÉCRIRE VOTE CODE ICI
}
//endregion


//region TODO 03 : Attacher des écouteurs d'évènements aux 2 éléments img
/**
 * Description : Fonction principale de l'application.
 * 				 Elle est appelée immédiatement après la fin du chargement du document HTML.
 *
 * Algorithme :
 *
 *  Inscrire les intructions permettant de réaliser les actions suivantes (2 instructions):
 *
 *      1. Attacher un écouteur à l'évènement "click" de l'élément "lumiereOn" qui exécutera la fonction eteindreLumiere
 *      2. Attacher un écouteur à l'évènement "click" de l'élément "lumiereOff" qui exécutera la fonction allumeLumiere
 */
function init() {

    // ÉCRIRE VOTE CODE ICI
}
//endregion
