/* Mise en situation
* Mr.Beast espère faire une collaboration Beast x Musknation et, pour cela, il a besoin de vous une dernière fois.
* Il veut que quand on clique sur le logo, ce dernier se transforme en image de Doge. Cependant, cette
* image est différente à chaque clic. Quand on n'a plus d'images, on recommence à la première.
* Indice : vous allez devoir utiliser un tableau
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : clicBouton */
function clicBouton(){



    // ECRIRE DU CODE ICI



}


