
/*  TODO 1
*   init() : Déclaration des 16 événements nécessaires
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index vaut plus de 16
*       et qui augmente de 1 à chaque itération.
*   2 - Dans la boucle, vous devez créer un événement de type "click" qui appelle
*       la fonction "devoiler". On a besoin de cet événement pour les éléments avec l'id
*       #image1, #image2, #image3, ..., jusqu'à #image16. C'est pour ça qu'on a besoin d'une
*       boucle pour éviter la répétition de code. Attention ! Il y a une seule ligne de
*       code dans la boucle.
*/
function init(){
    // Votre code ici

}

// NE PAS TOUCHER AU CODE À PARTIR D'ICI

// Variables globales
let step = 1;
let lastImage;

async function devoiler(){
    this.style.opacity = 1;
    if(step == 1){
        lastImage = this;
        step++;
    }
    else{
        if(this.getAttribute("src") == lastImage.getAttribute("src")){
            this.removeEventListener('click', devoiler);
            lastImage.removeEventListener('click', devoiler);
        }
        else{ 
            await sleep(1000);
            lastImage.style.opacity = 0;
            this.style.opacity = 0;
        }
        step--;
    }
}

// Mettre le programme en pause
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
  