
/* TODO 1 : fonction init
    À faire :
        1 - Appeler la fonction creerGrenouille en lui passant 5 paramètres :
                - la chaîne de carctères "grenouille1"
                - une couleur de votre choix parmi "Bleue", "Mauve", "Orange" ou "Verte"
                - un nombre entier de votre choix entre 0 et 600 (pour la position horizontale de la grenouille)
                - un nombre entier de votre choix entre 0 et 600 (pour la position verticale de la grenouille)
                - un nombre entier de votre choix entre 1 et 200 (pour la taille de la grenouille)
        2 - Appeler de nouveau la fonction creerGrenouille en lui passant 5 paramètres :
                - la chaîne de carctères "grenouille2"
                - une couleur de votre choix parmi "Bleue", "Mauve", "Orange" ou "Verte"
                - un nombre entier de votre choix entre 0 et 600 (pour la position horizontale de la grenouille)
                - un nombre entier de votre choix entre 0 et 600 (pour la position verticale de la grenouille)
                - un nombre entier de votre choix entre 1 et 200 (pour la taille de la grenouille)
        3 - Appeler de nouveau la fonction creerGrenouille en lui passant des valeurs différentes
            pour ses 5 paramètres, mais avec "grenouille3" comme premier paramètre
        4 - Appeler de nouveau la fonction creerGrenouille en lui passant des valeurs différentes
            pour ses 5 paramètres, mais avec "grenouille4" comme premier paramètre
*/
function init() {


// ECRIRE DU CODE ICI


}


/* TODO 2 : fonction creerGrenouille
    À faire :
        1 - Déclarer une variable nommée element et l'instancier avec l'élément avec l'ID idGrenouille
        2 - Modifier la valeur de l'attribut "src" de l'élément element
            pour "img/grenouille[couleur].png" où [couleur] est la valeur du paramètre couleur
        3 - Modifier la propriété de style left de l'élément element
            pour "[x]px" où [x] est la valeur du paramètre x
        4 - Modifier la propriété de style top de l'élément element
            pour "[y]px" où [y] est la valeur du paramètre y
        5 - Modifier la propriété de style width de l'élément element
            pour "[taille]px" où [taille] est la valeur du paramètre taille
        6 - Modifier la propriété de style height de l'élément element
            pour "[taille]px" où [taille] est la valeur du paramètre taille
 */
function creerGrenouille(idGrenouille, couleur, x, y, taille) {


// ECRIRE DU CODE ICI


}