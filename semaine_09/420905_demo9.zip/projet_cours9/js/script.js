// VARIABLES GLOBALES
let gIdsObjets = ["alambic", "ampoule", "bombe", "colis", "disquette"];
let gPlanificateur;

// Création des événements
function init(){
    
    // Écouteurs d'événements pour les 5 images d'objets
    for(let index = 0; index < gIdsObjets.length; index++){
        document.getElementById(gIdsObjets[index]).addEventListener("click", afficherNom);
        // afficherNom peut être remplacé par afficherInfo
    }

    // Écouteurs d'événements pour les boutons de quantité pour la bombe
    document.getElementById("boutonSomme").addEventListener("click", calculerSomme);

    // Écouteurs d'événements pour les planificateurs
    document.getElementById("boutonFantome").addEventListener("click", afficherFantome);
    document.getElementById("boutonCrewmate").addEventListener("click", alternerCrewmate);
    document.getElementById("stop").addEventListener("click", stopCrewmate);

    // Écouteurs d'événements clavier
    document.addEventListener("keydown", toucheClavier);
}

// ###########################
// #    SECTION SUR DATA-    #
// ###########################

function afficherNom(){
    // Obtenir le data-nom
    let nom = this.getAttribute("data-nom");

    // Afficher le nom dans la page
    document.getElementById("nom").textContent = nom;
}

function afficherInfo(){

    // Obtenir les données data-
    let nom = this.getAttribute("data-nom");
    let quantite = this.getAttribute("data-quantite");
    let danger = this.getAttribute("data-danger");

    // Afficher les données dans la page
    document.getElementById("nom").textContent = nom;
    document.getElementById("quantite").textContent = quantite;
    document.getElementById("danger").textContent = danger;

}

// À appeler dans la console
function bordureSiDanger(monId){

    // Obtenir la valeur de data-danger (Donc "Oui" ou "Non")
    let danger = document.getElementById(monId).getAttribute("data-danger");

    // Mettre une bordure rouge SI la valeur de data-danger est "Oui"
    if(danger == "Oui"){
        document.getElementById(monId).style.borderColor = "red";
    }

}

function calculerSomme(){
    // Obtenir la quantité de bombes et d'ampoules
    let quantiteBombe = document.getElementById("bombe").getAttribute("data-quantite");
    let quantiteAmpoule = document.getElementById("ampoule").getAttribute("data-quantite");

    // Convertir la quantité en nombre et les additionner
    let somme = parseInt(quantiteBombe) + parseInt(quantiteAmpoule);

    // Afficher la somme dans la page
    document.getElementById("quantiteSomme").textContent = somme;
}

// Affiche ou cache les champs quantité et danger. À appeler dans la console
function toggleCacher(){
    document.getElementById("champsOptionnels").classList.toggle("cacher");
}

// ########################################
// #    Section sur les planificateurs    #
// ########################################

// SETTIMEOUT

function afficherFantome(){

    // Afficher boo dans 2 secondes
    setTimeout(afficherBoo, 2000);

    // Cacher boo dans 4 secondes
    setTimeout(cacherBoo, 4000);

}

function afficherBoo(){
    document.getElementById("boo").style.display = "block";
}

function cacherBoo(){
    document.getElementById("boo").style.display = "none";
}

// SETINTERVAL

function alternerCrewmate(){
    gPlanificateur = setInterval(toggleCacher, 1000);
}

function toggleCacher(){
    document.getElementById("crewmate").classList.toggle("cacher");
}

function stopCrewmate(){
    clearInterval(gPlanificateur);
}

// ############################################
// #    Section sur les événements clavier    #
// ############################################

function toucheClavier(evenement){
    // On obtient et stocke la touche appuyée dans la variable touche
    let touche = evenement.key;

    if(touche == "ArrowUp"){
        document.getElementById("fondClavier").style.backgroundColor = "cornflowerblue";
    }
    else if(touche == "a"){
        document.getElementById("fondClavier").style.backgroundColor = "crimson";
    }
    else if(touche == "z"){
        document.getElementById("fondClavier").style.backgroundColor = "gold";
    }
}