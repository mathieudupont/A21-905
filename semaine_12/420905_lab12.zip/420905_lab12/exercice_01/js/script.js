// VARIABLES GLOBALES
let gMario;
let gLuigi;
let gPeach;
let gYoshi;

/* TODO 1
*  init() : Création des objets et écouteurs d'événement
*
*  /!\ Jeter un coup d'oeil au fichier Personnage.js pour commencer /!\
*
*  Instructions :
*  1 - Instancier un objet de type Personnage et le stocker dans la
*      variable gMario. Voici ses propriétés :
*       → nom : "mario".
*       → positionX : nombre de votre choix entre 50 et 700.
*       → positionY : nombre de votre choix entre 100 et 400.
*  2 - Instancier un autre objet Personnage similaire, mais son nom est
*      "luigi" et on le stocke dans la variable gLuigi.
*  3 - Instancier un autre objet Personnage similaire, mais son nom est
*      "peach" et on le stocke dans la variable gPeach.
*  4 - Instancier un autre objet Personnage similaire, mais son nom est
*      "yoshi" et on le stocke dans la variable gYoshi.
*/
function init(){

    // ÉCRIRE VOTRE CODE ICI

    // NE PAS TOUCHER À CETTE LIGNE DE CODE
    document.getElementById("bouton").addEventListener("click", afficherPersonnages);
}

// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
//     AUCUN CODE À MODIFIER À PARTIR D'ICI
// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

function afficherPersonnages(){

    afficherImage(gMario, "image1");
    afficherImage(gLuigi, "image2");
    afficherImage(gPeach, "image3");
    afficherImage(gYoshi, "image4");

}

function afficherImage(objet, id){
    let element = document.getElementById(id);
    element.style.display = "block";
    element.setAttribute("src", "images/" + objet.nom + ".png");
    element.style.left = objet.positionX + "px";
    element.style.top = objet.positionY + "px";
}

