/*  TODO 1
*   init() : Déclaration des 3 événements nécessaires pour les 3 boutons
*   RIEN À MODIFIER CI-DESSOUS. JUSTE REGARDER"
*/
function init(){
    // Bouton 1
    document.getElementById("bouton1").addEventListener('click', unDix);

    // Bouton 2
    document.getElementById("bouton2").addEventListener('click', unCent);

    // Bouton 3
    document.getElementById("bouton3").addEventListener('click', unCentPair);
}

/*  TODO 2
*   unDix() : Affiche les nombres de 1 à 10 dans l'élément avec l'id #resultat
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index vaut 11
*       et qui augmente de 1 à chaque itération.
*   2 - Ajouter l'instruction : document.getElementById("resultat").textContent += " " + index;
*       à l'intérieur de la boucle.
*/
function unDix(){
    // Nettoyer la fenêtre avec le résultat
    document.getElementById("resultat").textContent = "";

    // Boucle qui ajoute les nombres de 1 à 10
}

/*  TODO 3
*   unCent() : Affiche les nombres de 1 à 100 dans l'élément avec l'id #resultat
*   À faire :
*   1 - Créer une boucle qui commence à l'index 1, qui s'arrête si l'index vaut 101
*       et qui augmente de 1 à chaque itération.
*   2 - Ajouter l'instruction : document.getElementById("resultat").textContent += " " + index;
*       à l'intérieur de la boucle.
*/
function unCent(){
    // Nettoyer la fenêtre avec le résultat
    document.getElementById("resultat").textContent = "";

    // Boucle qui ajoute les nombres de 1 à 100
}

/*  TODO 4
*   unCent() : Affiche les nombres pairs de 1 à 100 dans l'élément avec l'id #resultat
*   À faire :
*   1 - Créer une boucle qui commence à l'index 2, qui s'arrête si l'index vaut 101
*       et qui augmente de 2 à chaque itération.
*   2 - Ajouter l'instruction : document.getElementById("resultat").textContent += " " + index;
*       à l'intérieur de la boucle.
*/
function unCentPair(){
    // Nettoyer la fenêtre avec le résultat
    document.getElementById("resultat").textContent = "";

    // Boucle qui ajoute les nombres pairs de 1 à 100
}
