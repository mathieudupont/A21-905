
let gTableau1 = [] ;
let gTableau2 = [] ;
let gTableau3 = [] ;

function init(){
    document.getElementById("bouton1").addEventListener("click", executerCode);
    afficherTableaux() ;
}

function executerCode(){

    // Exemples de tableaux :
    gTableau1 = [1, 2] ;
    gTableau2 = [1, 2, 3, 4] ;
    gTableau3 = [1, 2, 3, 4, 5, 6] ;

    // Exemple de choses à faire et à afficher le résultat :
    document.getElementById('resultat').textContent = gTableau2[1] + gTableau2[2];

    afficherTableaux() ;
}







function afficherTableaux(){

    let texte = '<tr><td class="index" style="background: black; box-shadow: none;">index</td>';
    for (let i = 0 ; i < Math.max(gTableau1.length, gTableau2.length, gTableau3.length) ; i++){
        texte += '<td class="index">' + i + '</td>';
    }
    texte += '</tr>';

    tableaux = [gTableau1, gTableau2, gTableau3];
    tableauxNoms = ['gTableau1', 'gTableau2', 'gTableau3'];
    for (let i = 0 ; i < 3 ; i++){
        texte += '<tr><td class="zone" style="color: white; background: black; box-shadow: none;">' + tableauxNoms[i] + '</td>';
        for (let j = 0 ; j < tableaux[i].length ; j++){
            texte += '<td class="zone">' + tableaux[i][j] + '</td>';
        }
        texte += '</tr>';
    }

    document.getElementById('tableau').innerHTML = texte;
}