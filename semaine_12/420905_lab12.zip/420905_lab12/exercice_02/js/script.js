// VARIABLES GLOBALES
let gPlanificateur;
let gGrenouille;

/* TODO 1 : Créer un objet de type Grenouille
*
*  /!\ Jetez un coup d'oeil au fichier Grenouille.js /!\
*
*  Instructions :
*  1 - Instancier un objet de type Grenouille et le stocker dans la
*      variable gGrenouille. Voici ses propriétés :
*      satiete : 60
*      hydratation : 75
*      energie : 90
*/
function init(){

    // ÉCRIRE VOTRE CODE ICI

    // NE PAS TOUCHER À CES LIGNES DE CODE
    document.getElementById("nourrir").addEventListener("click", nourrir);
    document.getElementById("abreuver").addEventListener("click", abreuver);
    document.getElementById("dormir").addEventListener("click", dormir);
    gPlanificateur = setInterval(affaiblir, 200);
}

/* TODO 2 : Dormir
*
*  Instructions :
*  1 - Affecter la valeur 120 pour la propriété energie de gGrenouille.
*/
function dormir(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 3 : Nourrir
*
*  Instructions :
*  1 - Augmenter la valeur de la propriété satiete de 20 pour gGrenouille.
*/
function nourrir(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 4 : Abreuver
*
*  Instructions :
*  1 - Augmenter la valeur de la propriété hydratation de 25 pour gGrenouille.
*/
function abreuver(){

    // ÉCRIRE VOTRE CODE ICI

}

// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
//     AUCUN CODE À MODIFIER À PARTIR D'ICI
// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

function affaiblir(){
    gGrenouille.satiete -= 1;
    gGrenouille.hydratation -= 2;
    gGrenouille.energie -= 3;
    afficherStatut();
}

function afficherStatut(){
    if(gGrenouille.satiete <= 0 || gGrenouille.hydratation <= 0 || gGrenouille.energie <= 0){
        document.getElementById("nourrir").removeEventListener("click", nourrir);
        document.getElementById("abreuver").removeEventListener("click", abreuver);
        document.getElementById("dormir").removeEventListener("click", dormir);
        clearInterval(gPlanificateur);
        document.getElementById("grenouille").setAttribute("src", "images/grenouilleMorte.png");
    }
    else{
        gGrenouille.satiete = Math.min(gGrenouille.satiete, 120);
        gGrenouille.hydratation = Math.min(gGrenouille.hydratation, 120);
        gGrenouille.energie = Math.min(gGrenouille.energie, 120);
        document.getElementById("satiete").style.width = gGrenouille.satiete + "px";
        document.getElementById("hydratation").style.width = gGrenouille.hydratation + "px";
        document.getElementById("energie").style.width = gGrenouille.energie + "px";
    }
}



