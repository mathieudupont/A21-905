/*  Exercice 13
    On souhaite que le Mario vert puisse se déplacer de 5 pixels
    à l'écran à chaque fois qu'on appuie sur une flèche du clavier.

    Quelques fonctions sont déjà codées. Il faudra les utiliser
    pour compléter l'exercice. (Lisez leur description pour bien
    les utiliser !)
*/

// VARIABLES GLOBALES

/* TODO 1 : init */
function init(){

    
}

/* TODO 2 : bougerLuigi */
function bougerLuigi(evenement){


}

/* --- deplacerVersLaGauche ---
*    Description : Déplace un élément HTML vers la gauche.
*  --- Paramètres ---
*    idElement : Id (entre guillemets) de l'élément à déplacer.
*    nbDePixels : Nombre de pixels du déplacement.
*/
function deplacerVersLaGauche(idElement, nbDePixels){
    let left = parseInt(document.getElementById(idElement).style.left);
    left = left - nbDePixels + "px";
    document.getElementById(idElement).style.left = left;
}

/* --- deplacerVersLaDroite ---
*    Description : Déplace un élément HTML vers la droite.
*/
function deplacerVersLaDroite(idElement, nbDePixels){
    let left = parseInt(document.getElementById(idElement).style.left);
    left = left + nbDePixels + "px";
    document.getElementById(idElement).style.left = left;
}

/* --- deplacerVersLeBas ---
*    Description : Déplace un élément HTML vers le bas.
*/
function deplacerVersLeBas(idElement, nbDePixels){
    let top = parseInt(document.getElementById(idElement).style.top);
    top = top + nbDePixels + "px";
    document.getElementById(idElement).style.top = top;
}

/* --- deplacerVersLeHaut ---
*    Description : Déplace un élément HTML vers le haut.
*/
function deplacerVersLeHaut(idElement, nbDePixels){
    let top = parseInt(document.getElementById(idElement).style.top);
    top = top - nbDePixels + "px";
    document.getElementById(idElement).style.top = top;
}



