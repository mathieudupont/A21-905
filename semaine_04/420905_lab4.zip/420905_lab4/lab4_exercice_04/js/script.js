// VARIABLE GLOBALE
let gNbAmpoulesLumineuses = 0;

/*  TODO 1
*   init() : Déclaration des 4 événements nécessaires pour les 4 ampoules
*   RIEN À CHANGER POUR CETTE FONCTION. JUSTE REGARDER.
*/
function init(){
    document.getElementById("ampoule1").addEventListener('click', allumerOuEteindre);
    document.getElementById("ampoule2").addEventListener('click', allumerOuEteindre);
    document.getElementById("ampoule3").addEventListener('click', allumerOuEteindre);
    document.getElementById("ampoule4").addEventListener('click', allumerOuEteindre);
}

/*  TODO 2
*   allumerOuEteindre() : Changer l'état d'un ampoule cliquée. Met à jour le nombre d'ampoules allumés affiché.
*
*   Attention : Étant donné que cette fonction gère toutes les ampoules, il faudra utiliser le mot-clé this.
*
*   À faire :
*   Créez un if ... else :
*   1 - Si la valeur de l'attribut "src" est-elle égale à "images/lightOff.png" (getAttribute)
*   2 -     On change la valeur de "src" pour "images/lightOn.png" (setAttribute)
*   3 -     On incrémente gNbAmpoulesLumineuses de 1.
*   4 - Sinon
*   5 -     On change la valeur de "src" pour "images/lightOff.png" (setAttribute)
*   6 -     On décrémente gNbAmpoulesLumineuses de 1.
*
*   7 - À la fin de la fonction, modifiez le contenu textuel de l'élément avec l'id "nombreAmpoules" :
*       → On veut afficher le nombre actuel d'ampoules lumineuses. (Car une ampoule vient de s'allumer / s'éteindre)
*/
function allumerOuEteindre(){
    // Votre if ... else ici

    // Votre code pour mettre à jour le nombre affiché d'ampoules allumées
}
