// Variables globales. IL N'Y A RIEN À AJOUTER.
let gTableau = [0, 1, 2, 3, 4, 5] ;


/* TODO 0
*  init() : Déclaration des évènements nécessaires.
*  IL N'Y A RIEN À AJOUTER. À consulter seulement.
*/
function init(){
    document.getElementById("bouton1").addEventListener("click", additionner10);
    document.getElementById("bouton2").addEventListener("click", multiplierPar2);
    document.getElementById("bouton3").addEventListener("click", exposant2);
    afficherTableau('number') ;
}


/* TODO 1
*  additionner10() : Additionne 10 aux valeurs des cellules et affiche le tableau.
*
*  À faire :
*   1 - Créer une boucle où l'index prend les valeurs de 0 jusqu'à la taille de gTableau moins un.
*       À chaque itération :
*   2 -     Additionner 10 aux valeurs des cellules de gTableau (et réaffecter les résultats aux cellules).
*
*   ATTENTION : il faut utiliser .length
*   ATTENTION : il ne doit y avoir qu'une seule ligne de code dans la boucle.
*/
function additionner10(){

    // ECRIRE DU CODE ICI


    // NE PAS TOUCHER À CETTE LIGNE DE CODE :
    afficherTableau('number') ;
}


/* TODO 2
*  multiplierPar2() : Multiplie les valeurs des cellules par 2 et affiche le tableau.
*
*  À faire :
*   1 - Créer une boucle où l'index prend les valeurs de 0 jusqu'à la taille de gTableau moins un.
*       À chaque itération :
*   2 -     Multiplier par 2 les valeurs des cellules de gTableau (et réaffecter les résultats aux cellules).
*
*   ATTENTION : il faut utiliser .length
*   ATTENTION : il ne doit y avoir qu'une seule ligne de code dans la boucle.
*/
function multiplierPar2(){

    // ECRIRE DU CODE ICI


    // NE PAS TOUCHER À CETTE LIGNE DE CODE :
    afficherTableau('number') ;
}


/* TODO 3
*  exposant2() : Multiplie les valeurs des cellules par elles-mêmes et affiche le tableau.
*
*  À faire :
*   1 - Créer une boucle où l'index prend les valeurs de 0 jusqu'à la taille de gTableau moins un.
*       À chaque itération :
*   2 -     Multiplier par elles-mêmes les valeurs des cellules de gTableau (et réaffecter les résultats aux cellules).
*
*   ATTENTION : il faut utiliser .length
*   ATTENTION : il ne doit y avoir qu'une seule ligne de code dans la boucle.
*/
function exposant2(){

    // ECRIRE DU CODE ICI


    // NE PAS TOUCHER À CETTE LIGNE DE CODE :
    afficherTableau('number') ;
}


// NE PLUS TOUCHER AU CODE À PARTIR D'ICI

function afficherTableau(type){

    if (gTableau.length > 0 && typeof gTableau[0] != type){
        alert('Mauvais type de valeurs dans le tableau!');
    }

    let texte = '<tr><td class="index" style="background: black; box-shadow: none;">index</td>';
    for (let i = 0 ; i < gTableau.length ; i++){
        texte += '<td class="index">' + i + '</td>';
    }
    texte += '</tr>';

    texte += '<tr><td class="zone" style="color: white; background: black; box-shadow: none;">gTableau</td>';
    for (let j = 0 ; j < gTableau.length ; j++){
        texte += '<td class="zone">' + gTableau[j] + '</td>';
    }
    texte += '</tr>';

    document.getElementById('tableau').innerHTML = texte;
}