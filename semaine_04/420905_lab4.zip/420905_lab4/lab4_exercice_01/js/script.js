/*  TODO 1
*   init() : Déclaration des 4 événements nécessaires pour les 4 carrés
*   À faire :
*   1 - Oups ! Il manque un événement à déclarer pour le #carre3 ! Détails plus bas.
*/
function init(){
    // Carré 1
    document.getElementById("carre1").addEventListener('click', cacherCarre);

    // Carré 2
    document.getElementById("carre2").addEventListener('mouseover', cacherCarre);
    document.getElementById("carre2").addEventListener('mouseout', afficherCarre);

    // Carré 3
    // Événement de type 'click' sur #carre3 qui appelle la fonction bougerCarre()
    // AJOUTEZ L'ÉVÉNEMENT ICI
}

/*  TODO 2
*   cacherCarre() : Ajoute la classe .cacher à l'élément qui appelle la fonction
*   À faire :
*   1 - Ajoutez une instruction qui ajoute la classe .cacher à l'élément ciblé.
*       → Vous aurez besoin d'utiliser le mot-clé this étant donné que 2 éléments différents
*         peuvent appeler cette fonction suite au déclenchement d'un événement.
*/
function cacherCarre(){
    // Ajoutez du code ici
}

/*  TODO 3
*   afficherCarre() : Retire la classe .cacher à l'élément #carre2
*   À faire :
*   1 - Ajoutez une instruction qui retire la classe .cacher à l'élément #carre2
*/
function afficherCarre(){
    // Ajoutez du code ici
}

/*  TODO 4
*   bougerCarre() : Ajoute / retirer la classe .bouger à l'élément #carre3
*   À faire :
*   1 - Ajoutez une instruction qui alterne entre ajouter / retirer la classe .bouger à l'élément #carre3
*       → Vous aurez besoin de toggle()
*/
function bougerCarre(){
    // Ajoutez du code ici
}

