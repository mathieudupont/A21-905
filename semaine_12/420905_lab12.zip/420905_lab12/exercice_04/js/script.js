// VARIABLES GLOBALES
let gIlyan;
let gPaule;
let gJulienFelix;

/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){

    document.getElementById("ilyan").addEventListener("click", allergiesIlyan);
    document.getElementById("paule").addEventListener("click", allergiesPaule);
    document.getElementById("julienfelix").addEventListener("click", allergiesJulienFelix);
    cacherToutesLesAllergies();
    initialiserEnfants();
    creerAllergies();

}

/* TODO 2 : creerAllergies
*
*  Instructions :
*  1 - Stocker, dans la propriété allergies de gIlyan, un tableau contenant
*      les aliments "cerise", "ananas" et "aubergine".
*  2 - Stocker, dans la propriété allergies de gPaule, un tableau contenant
*      un seul aliment : "fraise".
*  3 - Stocker, dans la propriété allergies de gJulienFelix, un tableau
*      contenant les aliments "banane", "citron", "melon", "orange", "pomme",
*      "raisin" et "cerise".
 */
function creerAllergies(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 3 : allergiesIlyan
/* TODO 3 : allergiesIlyan
*
*  Instructions :
*  1 - Appeler la fonction cacherToutesLesAllergies, qui ne prend aucun paramètre.
*  2 - Dans une boucle qui parcourt les éléments du tableau dans la propriété
*      allergies de gIlyan :
*  3 -      Déclarer une variable nommée aliment et l'instancier avec la valeur
*           de l'élément dans le tableau de la propriété allergies de gIlyan à
*           l'index courant.
*  4 -      Appeler la fonction afficherUneAllergie, qui prend 2 paramètres :
*           la valeur de la variable aliment et l'index courant.
 */
function allergiesIlyan(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 4 : allergiesPaule
*
*  Instructions :
*  1 - Appeler la fonction cacherToutesLesAllergies, qui ne prend aucun paramètre.
*  2 - Dans une boucle qui parcourt les éléments du tableau dans la propriété
*      allergies de gPaule :
*  3 -      Déclarer une variable nommée aliment et l'instancier avec la valeur
*           de l'élément dans le tableau de la propriété allergies de gPaule à
*           l'index courant.
*  4 -      Appeler la fonction afficherUneAllergie, qui prend 2 paramètres :
*           la valeur de la variable aliment et l'index courant.
 */
function allergiesPaule(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 5 : allergiesJulienFelix
*
*  Instructions :
*  1 - Appeler la fonction cacherToutesLesAllergies, qui ne prend aucun paramètre.
*  2 - Dans une boucle qui parcourt les éléments du tableau dans la propriété
*      allergies de gJulienFelix :
*  3 -      Déclarer une variable nommée aliment et l'instancier avec la valeur
*           de l'élément dans le tableau de la propriété allergies de gJulienFelix
*           à l'index courant.
*  4 -      Appeler la fonction afficherUneAllergie, qui prend 2 paramètres :
*           la valeur de la variable aliment et l'index courant.
 */
function allergiesJulienFelix(){

    // ÉCRIRE VOTRE CODE ICI

}

// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
//     AUCUN CODE À MODIFIER À PARTIR D'ICI
// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

function afficherUneAllergie(aliment, index){
    let element = document.getElementById("fruit" + (index + 1));
    element.setAttribute("src", "images/" + aliment + ".png");
    element.style.display = "block";
}

function cacherToutesLesAllergies(){
    for(let index = 1; index < 8; index++){
        document.getElementById("fruit" + index).style.display = "none";
    }
}

function initialiserEnfants(){
    gIlyan = new Enfant("Ilyan", null);
    gPaule = new Enfant("Paule", null);
    gJulienFelix = new Enfant("Julien-Felix", null);
}

