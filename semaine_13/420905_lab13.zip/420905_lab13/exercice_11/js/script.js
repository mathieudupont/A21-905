/* Mise en situation
 * Netflix est fier de votre travail. Il vous contacte pour modifier la publicité pour Squid Game.
 * Le jeu est le même qu'avant. Mais maintenant, Sae bouge vers la droite de 5px chaque 100ms quand on clique sur le bouton vert.
 * Et elle arrête d'avancer quand on clique sur le bouton rouge.
 */

// VARIABLES GLOBALES
let gPlanificateur;

/* TODO 1 : init */
function init(){


    // ECRIRE DU CODE ICI



}

/* TODO 2 : clicO */
function clicO(){



    // ECRIRE DU CODE ICI


}

/* TODO 3 : clicX */
function clicX(){



    // ECRIRE DU CODE ICI


}

//Indice : La position est une chaîne de caractère, il faut d'abord la convertir en chiffre
//         Une fois convertie, il faut rajouter "px" à la fin
function bougerDroite(){


    // ECRIRE DU CODE ICI


}
