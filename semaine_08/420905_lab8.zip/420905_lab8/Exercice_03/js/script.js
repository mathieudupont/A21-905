
/* TODO 1 : Rien à faire ici */
function init() {
    document.getElementById("bouton1").addEventListener('click', hirondelle);
    document.getElementById("bouton2").addEventListener('click', habit);
    document.getElementById("bouton3").addEventListener('click', pierre);
    document.getElementById("bouton4").addEventListener('click', oeuf);
}


/* TODO 2 : fonction suiteProverbe
    À faire :
        1 - Remplacer le contenu textuel de l'élément avec l'ID "suiteProverbe" par la valeur de suite
*/
function suiteProverbe(suite) {


// ECRIRE DU CODE ICI


}


/* TODO 3 : fonction hirondelle
    À faire :
        1 - Appeler la fonction suiteProverbe en lui passant comme paramètre la valeur "...le printemps."
*/
function hirondelle() {


// ECRIRE DU CODE ICI


}


/* TODO 4 : fonction habit
    À faire :
        1 - Appeler la fonction suiteProverbe en lui passant comme paramètre la valeur "...le moine."
*/
function habit() {


// ECRIRE DU CODE ICI


}


/* TODO 5 : fonction pierre
    À faire :
        1 - Appeler la fonction suiteProverbe en lui passant comme paramètre la valeur "...n'amasse pas mousse."
*/
function pierre() {


// ECRIRE DU CODE ICI


}


/* TODO 6 : fonction oeuf
    À faire :
        1 - Appeler la fonction suiteProverbe en lui passant comme paramètre la valeur "...vole un boeuf."
*/
function oeuf() {


// ECRIRE DU CODE ICI


}