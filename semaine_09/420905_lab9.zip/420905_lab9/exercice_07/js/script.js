//region DÉBUT DES VARIABLES GLOBALES
let gImgCol1 = ["cerise", "arcenciel", "bague", "huit", "melon", "foudre"], gIndex1 = 0;
let gImgCol2 = ["arcenciel", "cerise", "huit", "bague", "foudre", "melon"], gIndex2 = 0;
let gImgCol3 = ["bague", "cerise", "melon", "foudre", "huit", "arcenciel"], gIndex3 = 0;

let gPortefeuille = 10;
let gJeuActif = false;

// Variables pour stocker les planificateurs des 3 colonnes
let gPlanificateurColonne1;
let gPlanificateurColonne2;
let gPlanificateurColonne3;

// Quelle colonne est en train de bouger ?
let gCol1Active = false;
let gCol2Active = false;
let gCol3Active = false;

//endregion FIN DES VARIABLES GLOBALES


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    afficherIcones();

    document.addEventListener("keydown", clavier);
}


/* TODO 2
*  À faire :
* 1 - Déclarer la variable nommée touche et l'instancier avec la 
*     valeur de la touche appuyée.
* 2 - Si la variable touche est égale à "a"
* 3 -       Appeler la fonction jouer. Elle ne prend aucun paramètre.
*
* 4 - Si la variable touche est égale à "ArrowLeft"
* 5 -       Appeler la fonction stop1. Elle ne prend aucun paramètre.
*
* 6 - Si la variable touche est égale à "ArrowDown"
* 7 -       Appeler la fonction stop2. Elle ne prend aucun paramètre.
*
* 8 - Si la variable touche est égale à "ArrowRight"
* 9 -       Appeler la fonction stop3. Elle ne prend aucun paramètre.
*/
function clavier(evenement){

    // ECRIRE DU CODE ICI






}


/* TODO 3
*  À faire :
*  1 - Si la variable gPortefeuille est inférieure à 1 OU que la variable 
*      gJeuActif est égale à true
*  2 -      Créer une alerte qui envoie le message "Vous ne pouvez plus jouer.".
*
*  3 - Sinon
*  4 -      Créer un planificateur qui appelle la fonction changerColonne1 toutes
*           les 200 millisecondes et le mettre dans la variable gPlanificateurColonne1.
*  5 -      Créer un planificateur qui appelle la fonction changerColonne2 toutes
*           les 200 millisecondes et le mettre dans la variable gPlanificateurColonne2.
*  6 -      Créer un planificateur qui appelle la fonction changerColonne3 toutes
*           les 200 millisecondes et le mettre dans la variable gPlanificateurColonne3.
*  7 -      Appeler la fonction activerJeu. Elle ne prend aucun paramètre.
*/
function jouer(){

    // ECRIRE DU CODE ICI






}


/* TODO 4
*  À faire (à l'intérieur du if) :
*       1 - Mettre fin au planificateur se trouvant dans la variable gPlanificateurColonne1.
*       2 - Changer la propriété de style display de l'élément avec l'id "stop1" pour la valeur "none".
*       3 - Affecter la valeur false à la variable gCol1Active.
*       4 - Appeler la fonction finJeu. Elle ne prend aucun paramètre.
*/
function stop1(){

    if(gCol1Active){

        // ECRIRE DU CODE ICI





    }

}


/* TODO 5
*  À faire (à l'intérieur du if) :
*       1 - Mettre fin au planificateur se trouvant dans la variable gPlanificateurColonne2.
*       2 - Changer la propriété de style display de l'élément avec l'id "stop2" pour la valeur "none".
*       3 - Affecter la valeur false à la variable gCol2Active.
*       4 - Appeler la fonction finJeu. Elle ne prend aucun paramètre.
*/
function stop2(){

    if(gCol2Active){

        // ECRIRE DU CODE ICI





    }

}


/* TODO 6
*  À faire (à l'intérieur du if) :
*       1 - Mettre fin au planificateur se trouvant dans la variable gPlanificateurColonne3.
*       2 - Changer la propriété de style display de l'élément avec l'id "stop3" pour la valeur "none".
*       3 - Affecter la valeur false à la variable gCol3Active.
*       4 - Appeler la fonction finJeu. Elle ne prend aucun paramètre.
*/
function stop3(){

    if(gCol3Active){

        // ECRIRE DU CODE ICI






    }
    
}


//region NE PAS MODIFIER LE CODE À PARTIR D'ICI

function changerColonne1(){
    gIndex1 = (gIndex1 + 1) % gImgCol1.length;
    afficherColonne(gIndex1, gImgCol1, 1);
}

function changerColonne2(){
    gIndex2 = (gIndex2 + 1) % gImgCol2.length;
    afficherColonne(gIndex2, gImgCol2, 2);
}

function changerColonne3(){
    gIndex3 = (gIndex3 + 1) % gImgCol3.length;
    afficherColonne(gIndex3, gImgCol3, 3);
}

function afficherIcones(){
    afficherColonne(gIndex1, gImgCol1, 1);
    afficherColonne(gIndex2, gImgCol2, 2);
    afficherColonne(gIndex3, gImgCol3, 3);
}

function afficherColonne(index, tableau, col){
    for(let i = 1; i < 6; i++){
        let numImage = (index + (i - 3)) % tableau.length;
        numImage = numImage < 0 ? numImage + tableau.length : numImage;
        document.getElementById("col" + col + "row" + i).setAttribute("src", "images/" + tableau[numImage] + ".png")
    }
}

function activerJeu(){
    for(let index = 1; index < 4; index++){
        document.getElementById("stop" + index).style.display = "block";
    }
    gPortefeuille -= 1;
    document.getElementById("portefeuille").textContent = gPortefeuille;
    gCol1Active = true;
    gCol2Active = true;
    gCol3Active = true;
    document.getElementById("message").textContent = "C'est parti !";
    gJeuActif = true;
}

function finJeu(){
    if(!gCol1Active && !gCol2Active && !gCol3Active){
        gJeuActif = false;
        if(gImgCol1[gIndex1] == gImgCol2[gIndex2] && gImgCol1[gIndex1] == gImgCol3[gIndex3]){
            gPortefeuille += 5;
            document.getElementById("portefeuille").textContent = gPortefeuille;
            document.getElementById("message").textContent = "Bien joué ! +5$ ";
        }
        else{
            document.getElementById("message").textContent = "Aïe. Meilleure chance la prochaine fois.";
        }
    }
}
//endregion