// VARIABLES GLOBALES
let gTemperature = 20;  // Nombre entier pour la température en celsius


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    document.getElementById("chaud").addEventListener("click", augmenterTemperature);
    document.getElementById("froid").addEventListener("click", reduireTemperature);
}


/* TODO 2
*  À faire :
*  1 - Augmenter la valeur de la variable gTemperature de 1.
*  2 - Changer la propriété de style display de l'élément ciblé pour la valeur "none".
*  3 - Utiliser un planificateur pour appeler seulement une fois la fonction
*      ajusterTemperaturePiece dans 750 millisecondes.
*/
function augmenterTemperature(){

    // ECRIRE DU CODE ICI




}


/* TODO 3
*  À faire :
*  1 - Réduire la valeur de la variable gTemperature de 1.
*  2 - Changer la propriété de style display de l'élément ciblé pour la valeur "none".
*  3 - Utiliser un planificateur pour appeler seulement une fois la fonction
*      ajusterTemperaturePiece dans 500 millisecondes.
*/
function reduireTemperature(){

    // ECRIRE DU CODE ICI




}


/* TODO 4
*  À faire :
*  1 - Changer la propriété de style display de l'élément avec l'id "chaud"
*      pour la valeur "block".
*  2 - Changer la propriété de style display de l'élément avec l'id "froid"
*      pour la valeur "block".
*  3 - Mettre dans le contenu textuel de l'élément avec l'id "temperature"
*      la valeur de la variable gTemperature
*  4 - Appeler la fonction changerFond en lui passant un
*      paramètre : la variable gTemperature.
*/
function ajusterTemperaturePiece(){

    // ECRIRE DU CODE ICI




}



//region NE PAS CHANGER CETTE FONCTION
function changerFond(temperature){

    if(temperature > 25){
        document.getElementById("conteneur").style.backgroundColor = "#F49D6B";
    }
    else if(temperature > 22){
        document.getElementById("conteneur").style.backgroundColor = "#EDCEC0";
    }
    else if(temperature < 15){
        document.getElementById("conteneur").style.backgroundColor = "#93F6FF";
    }
    else if(temperature < 18){
        document.getElementById("conteneur").style.backgroundColor = "#DDFAFF";
    }
    else{
        document.getElementById("conteneur").style.backgroundColor = "#E7E7E7";
    }

}
//endregion