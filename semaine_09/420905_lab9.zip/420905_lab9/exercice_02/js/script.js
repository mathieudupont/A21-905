// VARIABLES GLOBALES (AUCUNE)


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){

    document.getElementById("boutonBombe").addEventListener("click", bruitBombe);
    document.getElementById("boutonCadran").addEventListener("click", heureCadran);
    document.getElementById("boutonTelephone").addEventListener("click", couleurTelephone);
    document.getElementById("boutonToilette").addEventListener("click", usageToilette);
    document.getElementById("boutonAfficher").addEventListener("click", afficherTout);

}


/* TODO 2
*  À faire :
*  1 - Mettre dans l'attribut "data-bruit" de l'élément avec l'id "bombe"
*      la chaîne de caractères "BOOM".
*  2 - Mettre une couleur de fond "gold" à l'élément avec l'id "bombe".
*/
function bruitBombe(){

    // ECRIRE DU CODE ICI




}


/* TODO 3
*  À faire :
*  1 - Mettre dans l'attribut "data-heure" de l'élément avec l'id "cadran"
*      la chaîne de caractères "10h37".
*  2 - Mettre une couleur de fond "gold" à l'élément avec l'id "cadran".
*/
function heureCadran(){

    // ECRIRE DU CODE ICI




}


/* TODO 4
*  À faire :
*  1 - Mettre dans l'attribut "data-couleur" de l'élément avec l'id "telephone"
*      la chaîne de caractères "Rouge".
*  2 - Mettre une couleur de fond "gold" à l'élément avec l'id "telephone".
*/
function couleurTelephone(){

    // ECRIRE DU CODE ICI




}


/* TODO 5
*  À faire :
*  1 - Mettre dans l'attribut "data-usage" de l'élément avec l'id "toilette"
*      la chaîne de caractères "87".
*  2 - Mettre une couleur de fond "gold" à l'élément avec l'id "toilette".
*/
function usageToilette(){

    // ECRIRE DU CODE ICI




}


//region NE PAS MODIFIER CETTE FONCTION
function afficherTout(){
    document.getElementById("infoBombe").textContent = document.getElementById("bombe").getAttribute("data-bruit");
    document.getElementById("infoCadran").textContent = document.getElementById("cadran").getAttribute("data-heure");
    document.getElementById("infoTelephone").textContent = document.getElementById("telephone").getAttribute("data-couleur");
    document.getElementById("infoToilette").textContent = document.getElementById("toilette").getAttribute("data-usage");
}
//endregion