/*  Exercice 16
    Quand on clique sur le bouton, des qualités se mettent à défiler très
    rapidement. (Toute les 100 millisecondes) Quand on clique à nouveau dessus,
    le défilement s'arrête et on tombe sur notre ... plus grande qualité,
    déterminée par le hasard.

    Une des fonctions est déjà remplie et permet de faire défiler les qualités
    quand on l'apelle à répétition.
*/

// VARIABLES GLOBALES


/* TODO 1 : init */
function init(){


}

/* TODO 2 : lancerOuArreterDefilement */
function lancerOuArreterDefilement(){


}

/* --- defilementRapide ---
   Description : Cette fonction change la qualité actuelle pour une autre qualité.
*/
function defilementRapide(){
    let q = document.getElementById("bouton").textContent;
    document.getElementById("bouton").textContent =
        (q === "Ponctuel(le)" ? "Cordial(e)" :
        (q === "Cordial(e)" ? "Poli(e)" :
        (q === "Poli(e)" ? "Concis(e)" :
        (q === "Concis(e)" ? "Modéré(e)" :
        (q === "Modéré(e)" ? "Prudent(e)" :
        (q === "Prudent(e)" ? "Raisonnable" :
        (q === "Raisonnable" ? "Détendu(e)" :
        (q === "Détendu(e)" ? "Avisé(e)" :
        (q === "Avisé(e)" ? "Circonspect(e)" :
        (q === "Circonspect(e)" ? "Retenu(e)" :
        (q === "Retenu(e)" ? "Flegmatique" :
        (q === "Flegmatique" ? "Décontracté(e)" :
        "Ponctuel(le)"))))))))))));
}