// Classe Enfant
/* Propriétés :
*  nom : Prénom de l'enfant. (Chaîne de caractères)
*  allergies : Tableau contenant les allergies de l'enfant.
*/
class Enfant{
    constructor(nom, allergies){
        this.nom = nom;
        this.allergies = allergies;
    }
}