/* Mise en situation
* Votre client ClosedSea veut une page pour vendre ses Non Fungible Tokens.
* La bordure du mouton devient verte quand on l'achète et rouge quand on le vend.
 */

// VARIABLES GLOBALES


/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : acheter */
function acheter(){



    // ECRIRE DU CODE ICI



}

/* TODO 3 : vendre */
function vendre(){



    // ECRIRE DU CODE ICI



}


