// Étape 3 - Appeler des fonctions dans la console

/* Ci-dessous, il y a 3 fonctions mystérieuses pour les questions de l'étape 3. (22 à 24)
Trouvez quelle utiliser pour chaque question ! */

function mystere1(){
    document.getElementById("deux").textContent = "Jouer au bowling.";
}

function mystere2(){
    document.getElementById("cadeau").textContent = "Le meilleur cadeau ?";
}

function mystere3(){
    let texteActuel = document.getElementById("cochonTitre").textContent;
    document.getElementById("cochonTitre").textContent = texteActuel + " sont super";
}

// Étape 4 - If else

/* Ci-dessous, il y a X fonctions utilisant des instructions conditionnelles (if / else)
associées à l'étape 4 du laboratoire
 */

function condition1(){
    let a = 1;
    if(a == 1){
        document.getElementById("resultat").textContent = "La variable a contient la valeur 1 !";
    }
}

function condition2(){
    let b = 2;

    // On retire le texte pour commencer
    document.getElementById("resultat").textContent = "";

    if(b > 3){
        document.getElementById("resultat").textContent = "La variable b contient une valeur supérieure à 3 !";
    }
}

function condition3(){
    let c = "Salut";

    if(c == "Bonjour"){
        document.getElementById("resultat").textContent = "Bonjour à vous.";
    }
    else{
        document.getElementById("resultat").textContent = "Au revoir.";
    }
}

function condition4(){
    let d = -5;

    if(d > 0){
        document.getElementById("resultat").textContent = "La variable d contient un nombre positif.";
    }
    else if(d < 0){
        document.getElementById("resultat").textContent = "La variable d contient un nombre négatif.";
    }
    else{
        document.getElementById("resultat").textContent = "La variable d contient 0";
    }
}

function condition5(){
    let e = 10;

    // Ajoutez du code ici !

}

function condition6(){
    let f = "cochon";

    // Ajoutez du code ici !

}

function condition7(){
    let g = true;

    // Ajoutez du code ici !

}

