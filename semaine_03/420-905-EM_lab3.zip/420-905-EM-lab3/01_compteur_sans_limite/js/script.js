//region DÉCLARATION DES VARIABLES GLOBALES (ACCESSIBLES PARTOUT)
let compteur;
//endregion


//region TODO 01 : Regarder la fonction init (CONSULTATION SEULEMENT)
/**
 * Fonction principale de l'application.
 * Elle est appelée immédiatement après la fin du chargement du document HTML.
 */
function init() {
    //RIEN NE DOIT ÊTRE MODIFIÉ DANS CETTE FONCTION, VOUS POUVEZ PASSER AU TODO SUIVANT
    //Lier les évènements souhaités des éléments aux fonctions à exécuter
    compteur = 0;
    document.getElementById("compteurId").textContent = compteur + "";
    document.getElementById("flecheBas").addEventListener("click", compteurVersLeBas);
    document.getElementById("flecheHaut").addEventListener("click", compteurVersLeHaut);
}
//endregion


//region TODO 02 : Compléter la fonction compteurVersLeHaut()
/**
 * Description : Cette fonction s'exécute suite à un évènement 'click'.  Lors d'un clic de souris, la valeur du compteur
 *               affichée sur la scène augmente de 1
 *
 * Algorithme :
 *
 *      1. Augmenter la valeur de la variable globale compteur de 1
 *      2. Assigner la nouvelle valeur du compteur à la propriété textContent de l'élément "compteurId" sur la scène
 */
function compteurVersLeHaut() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region TODO 03 : Compléter la fonction compteurVersLeBas()
/**
 * Description : Cette fonction s'exécute suite à un évènement 'click'.  Lors d'un clic de souris, la valeur du compteur
 *               affichée sur la scène diminue de 1
 *
 * Algorithme :
 *
 *      1. Diminuer la valeur de la variable globale compteur de 1
 *      2. Assigner la nouvelle valeur du compteur à la propriété textContent de l'élément compteurId sur la scène
 */
function compteurVersLeBas() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion
