/* Mise en situation
* (Encore!) Mr.Beast voudrait qu'on affiche toutes les images des grades sous le champ Grade pour inciter les usagers à cliquer.
* Il a entendu Elon Musk dire "les boucles, c'est le futur" et il veut donc que vous utilisiez une boucle.
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : clicBouton */
function clicBouton(){



    // ECRIRE DU CODE ICI



}


