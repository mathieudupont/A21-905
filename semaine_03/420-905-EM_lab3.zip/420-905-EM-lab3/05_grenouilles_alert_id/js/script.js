
//region TODO 01 : fonction clickSurGrenouille()
/**
 * Description : Afficher dans une fenêtre le "id" de la grenouille cliquée.
 *
 * Algorithme : - Appeler la fonction "alert" en lui passant (entre parenthèses) la chaîne de caractère suivante :
 *                      "Je suis la grenouille : [couleur]"
 *                où [couleur] doit être remplacé par le "id" de la grenouille cliquée
 *
 * Attention : Il faut utiliser le mot-clé this et l'attribut "id" de l'élément cliqué
 */
function clickSurGrenouille() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region CODE À NE PAS MODIFIER
/**
 * Description : Préparation du canvas
 */
function preparationCanvasPourExercice() {
    preparerUneGrenouille("Bleue");
    preparerUneGrenouille("Mauve");
    preparerUneGrenouille("Orange");
    preparerUneGrenouille("Verte");
}

/**
 * Description : Permet d'ajouter une nouvelle grenouille à la scène
 */
function preparerUneGrenouille(pCouleur) {
    let grenouille = document.getElementById("grenouille" + pCouleur);
    grenouille.addEventListener('click', clickSurGrenouille);
    grenouille.style.top = genererNombreAleatoire(0, 200) + "px";
    grenouille.style.left = genererNombreAleatoire(0, 400) + "px";
}

/**
 * Permet de générer un nombre entier alétoire compris entre deux valeurs inclusivement
 * @param {la valeur minimum possible pouvant être générée} min 
 * @param {la valeur maximum possible pouvant être générée} max 
 */
function genererNombreAleatoire(min, max) {
    return Math.floor(Math.random() * (+max - +min));
}
//endregion


/**
 * Description : Fonction appelée immédiatement après le chargement de la page HTML
 */
function init() {
    preparationCanvasPourExercice();
}
