// VOUS AVEZ 8 BOUTONS À CODER ! Testez-les un à la fois !
// Pour chaque bouton, la solution peut prendre une seule ligne de code.

/* TODO 1
*  init() : Déclaration de tous les événements nécessaires.
*  IL N'Y A RIEN À MODIFIER DANS CETTE FONCTION. JUSTE REGARDER.
*/
function init(){
    // Chaque bouton est associé à une fonction différente

    // Boutons qui changent l'attribut style
    document.getElementById("bouton1").addEventListener('click', bouton1);
    document.getElementById("bouton2").addEventListener('click', bouton2);
    document.getElementById("bouton3").addEventListener('click', bouton3);

    // Boutons qui changent l'image
    document.getElementById("bouton4").addEventListener('click', bouton4);
    document.getElementById("bouton5").addEventListener('click', bouton5);

    // Boutons qui changent l'attribut title
    document.getElementById("bouton6").addEventListener('click', bouton6);
    document.getElementById("bouton7").addEventListener('click', bouton7);
    document.getElementById("bouton8").addEventListener('click', bouton8);
}

/*  TODO 2
*   bouton1() : Rend la bordure gauche de l'image rouge
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "border-left-color:crimson" à l'attribut "style".
*   (Utilisez setAttribute)
*/
function bouton1(){
    // Ajoutez du code ici
}

/*  TODO 3
*   bouton3() : Rend la bordure droite de l'image rouge
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "border-right-color:crimson" à l'attribut "style".
*   (Utilisez setAttribute)
*/
function bouton3(){
    // Ajoutez du code ici
}

/*  TODO 4
*   bouton2() : Nous indique quelle est la valeur actuelle de l'attribut style pour l'image
*   À faire :
*   1 - Pour l'élément avec l'id #texteStyle, on veut modifier le contenu textuel.
*   → Le nouveau contenu textuel sera la valeur de l'attribut "style" pour l'élément avec l'id #image.
*   (Utilisez getAttribute)
*/
function bouton2(){
    // Ajoutez du code ici
}

/*  TODO 5
*   bouton4() : Change l'image centrale pour choix.png
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "images/choix.png" à l'attribut "src".
*   (Utilisez setAttribute)
*/
function bouton4(){
    // Ajoutez du code ici
}

/*  TODO 6
*   bouton5() : Change l'image centrale pour boutons.png
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "images/boutons.png" à l'attribut "src".
*   (Utilisez setAttribute)
*/
function bouton5(){
    // Ajoutez du code ici
}

/*  TODO 7
*   bouton6() : Change le tooltip (title) de l'image
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "Image avec boutons" à l'attribut "title".
*   (Utilisez setAttribute)
*/
function bouton6(){
    // Ajoutez du code ici
}

/*  TODO 8
*   bouton8() : Change le tooltip (title) de l'image
*   À faire :
*   1 - Pour l'élément avec l'id #image, donnez la valeur "Boutons dans une image" à l'attribut "title".
*   (Utilisez setAttribute)
*/
function bouton8(){
    // Ajoutez du code ici
}

/*  TODO 9
*   bouton7() : Nous indique quelle est la valeur actuelle de l'attribut class pour l'image
*   À faire :
*   1 - Pour l'élément avec l'id #texteTitle, on veut modifier le contenu textuel.
*   → Le nouveau contenu textuel sera la valeur de l'attribut "class" pour l'élément avec l'id #image.
*   (Utilisez getAttribute)
*/
function bouton7(){
    // Ajoutez du code ici
}

