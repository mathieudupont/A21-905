/*
    On peut modifier yoshi : Changer sa taille, sa couleur
    et le rendre invisible ou non. Il faut rendre les boutons
    fonctionnels et utiliser la classe Yoshi.js

    Initialement, on aimerait que Yoshi soit vert, ait une taille
    de 100 et soit visible.

    Une fonction est déjà codé et permet de mettre à jour l'affichage
    de Yoshi si une de ses propriétés a été changée. Appelez-la à chaque
    fois que vous modifiez une des propriétés de Yoshi.
*/

// VARIABLES GLOBALES

/* TODO 1 : init */
function init(){


}

/* TODO 2 : rendreYoshiVert */
function rendreYoshiVert(){


}

/* TODO 3 : rendreYoshiRose */
function rendreYoshiRose(){


}

/* TODO 4 : rendreYoshiBleu */
function rendreYoshiBleu(){


}

/* TODO 5 : aggrandirYoshi */
function aggrandirYoshi(){


}

/* TODO 6 : rapetisserYoshi */
function rapetisserYoshi(){


}

/* TODO 7 : rendreYoshiVisible */
function rendreYoshiVisible(){


}

/* TODO 8 : rendreYoshiInvisible */
function rendreYoshiInvisible(){


}

/* --- afficherYoshi ---
   Description : Cette fonction doit être appelée à chaque fois
   qu'une propriété de Yoshi a été modifiée.
   --- Paramètres ---
   objetYoshi : Une variable qui contient un objet de type Yoshi.
*/
function afficherYoshi(objetYoshi){
    document.getElementById("yoshi").setAttribute("src",
        "images/yoshi" + objetYoshi.couleur + ".png");
    document.getElementById("yoshi").style.width = objetYoshi.taille + "px";
    if(objetYoshi.visible){
        document.getElementById("yoshi").style.display = "inline";
    }
    else{
        document.getElementById("yoshi").style.display = "none";
    }
}
