// VARIABLES GLOBALES
let gPompe;
let gLitresAchat = 0;

/* TODO 1 : Créer un objet de type PompeAEssence dans init()
*
*  /!\ Jetez un coup d'oeil au fichier PompeAEssence.js /!\
*
*  Instructions :
*  1 - Instancier un objet de type PompeAEssence et le stocker dans
*      la variable gPompe. Voici ses propriétés :
*      prixDuLitre : 1.55
*      litresRestants : 120
*      horsService : false
*/
function init(){

    // ÉCRIRE VOTRE CODE ICI

    // NE PAS TOUCHER À CES LIGNES DE CODE
    document.getElementById("reduire").addEventListener("click",reduireQuantite);
    document.getElementById("augmenter").addEventListener("click",augmenterQuantite);
    document.getElementById("confirmer").addEventListener("click",confirmerAchat);
}

/* TODO 2 : reduireQuantite
*
*  Instructions :
*  1 - Si gLitresAchat est plus grand ou égal à 5
*       2 - Réduire la valeur de gLitresAchat de 5.
*       3 - Appeler la fonction actualiserAffichage(). (Aucun paramètre)
*/
function reduireQuantite(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 3 : augmenterQuantite
*
*  Instructions :
*  1 - Si gLitresAchat est plus petit ou égal à la propriété litresRestants
*      de gPompe moins 5
*       2 - Augmenter la valeur de gLitresAchat de 5.
*       3 - Appeler la fonction actualiserAffichage(). (Aucun paramètre)
*/
function augmenterQuantite(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 4 : confirmerAchat
*
*  Instructions :
*  1 - Réduire la valeur de la propriété litresRestants de gPompe
*      de la valeur dans la vairable gLitresAchat.
*  2 - Si la propriété litresRestants de gPompe est égale à 0
*       3 - Affecter true à la propriété horsService de gPompe
*  4 - Affecter 0 à gLitresAchat
*  5 - Appeler la fonction actualiserAffichage(). (Aucun paramètre)
*/
function confirmerAchat(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 5 : actualiserAffichage
*
*  Instructions :
*  1 - Pour le contenu textuel de l'élément avec l'id "prix", mettre
*      la valeur de la propriété prixDuLitre de gPompe multiplié par
*      la valeur de gLitresAchat.
*  2 - Pour le contenu textuel de l'élément avec l'id "quantiteLitres",
*      mettre la valeur de gLitresAchat.
*  3 - Pour le contenu textuel de l'élément avec l'id "litresRestants",
*      mettre la valeur de la propriété litresRestants de gPompe.
*  4 - Si la propriété horsService de gPompe est true
*       5 - Changer la couleur de la bordure (borderColor) de l'élément
*       avec l'id "pompe" pour la couleur "crimson".
*/
function actualiserAffichage(){

    // ÉCRIRE VOTRE CODE ICI

}
