//region Variables globales et constante (à consulter uniquement)
let gTableauPersonnages = ["pikachu"];
//endregion


//region TODO 01 : fonction init() - NE RIEN MODIFIER, SEULEMENT REGARDER
/**
 * Description : Cette fonction ajoute les écouteurs à la page sur les trois images
 */
function init() {
    document.getElementById("fantomas").addEventListener("click", ajouterFantome);
    document.getElementById("pikachu").addEventListener("click", ajouterPikachu);
    document.getElementById("frankie").addEventListener("click", ajouterFrankie);
    afficherTableau();
}
//endregion


//region TODO 02 : fonction ajouterFantome()
/**
 * Description : Permet d'ajouter le mot "fantomas" au texte et de l'afficher
 *
 * Algorithme : 1. Ajouter le mot "fantomas" au tableau des personnages
 *				2. Appeler la fonction pour afficher le tableau
 */
function ajouterFantome() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 03 : fonction ajouterPikachu()
/**
 * Description : Permet d'ajouter le mot "pikachu" au texte et de l'afficher
 *
 * Algorithme : 1. Ajouter le mot "pikachu" au tableau des personnages
 *				2. Appeler la fonction pour afficher le tableau
 */
function ajouterPikachu() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 04 : fonction ajouterFrankie()
/**
 * Description : Permet d'ajouter le mot "frankie" au texte et de l'afficher
 *
 * Algorithme : 1. Ajouter le mot "frankie" au tableau des personnages
 *				2. Appeler la fonction pour afficher le tableau
 */
function ajouterFrankie() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region CODE À NE PAS MODIFIER

/**
 * Description : Permet d'afficher le tableau sur la page
 */
function afficherTableau() {
    document.getElementById("texteHalloween").textContent = "";
    for (var index = 0; index < gTableauPersonnages.length; index++) {
        document.getElementById("texteHalloween").textContent += gTableauPersonnages[index] + " ";
    }
}
//endregion
