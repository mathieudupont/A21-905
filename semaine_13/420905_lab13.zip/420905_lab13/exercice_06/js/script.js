/* Mise en situation
* Le Youtubeur Mr.Beast a besoin de vous pour coder un nouveau challenge.
* Il veut donner 50¢ chaque fois que quelqu'un clique sur le gros bouton.
* Pour prouver que la personne a cliqué, on ajoute "BEAST " à la phrase, on
* affiche combien de clics ont été réalisés et combien d'argent a été obtenu.
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : clicBouton */
function clicBouton(){



    // ECRIRE DU CODE ICI



}


