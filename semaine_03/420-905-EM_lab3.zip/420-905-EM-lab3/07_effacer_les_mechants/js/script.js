
//region DÉCLARATION DES VARIABLES GLOBALES (ACCESSIBLE PARTOUT)
let opacityMechant1 = 1;
let opacityMechant2 = 1;
let opacityMechant3 = 1;
//endregion

//region TODO 01 : init()
/**
 * Description : Fonction appelée immédiatement après le chargement de la page HTML
 *
 * Algorithme :     Pour chaque méchant, attacher un évènement "click"
 *                  qui appelle la fonction associée au méchant :
 *                      1. masquerMechant1_Graduellement
 *                      2. masquerMechant2_Graduellement
 *                      3. masquerMechant3_Graduellement
 *
 *                  Pour chaque méchant, attacher un évènement "mouseout"
 *                  qui appelle la fonction associée au méchant :
 *                      4. reapparaitreMechant1
 *                      5. reapparaitreMechant2
 *                      6. reapparaitreMechant3
 */
function init() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region TODO 02 : fonctions masquerMechant1_Graduellement(), masquerMechant2_Graduellement(), masquerMechant3_Graduellement()
/**
 * Description : Faire disparaitre graduellement les méchants.
 *               Les fonctions sont appelées lors d'un "click" sur l'élément représentant le méchant
 * 
 * Algorithme :
 *      1. Réduire l'opacité de 0.1 de l'élément ayant lancé l'évènement (variable globale)
 *      2. Mettre à jour l'attribut opacity de l'élément correspondant
 *
 * Astuce : on peut concaténer un nombre avec une chaîne de caractères (même vide)
 *          pour obtenir une chaîne de caractères
 */
function masquerMechant1_Graduellement() {

    // ÉCRIRE VOTRE CODE ICI

}
function masquerMechant2_Graduellement() {

    // ÉCRIRE VOTRE CODE ICI

}
function masquerMechant3_Graduellement() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion


//region TODO 03 : fonctions reapparaitreMechant1(), reapparaitreMechant2(), reapparaitreMechant3()
/**
 * Description : Faire réapparaitre les méchants.
 *               Les fonctions sont appelées lors d'un "mouseout" de l'élément représentant le méchant
 * 
 * Algorithme :
 *      1. Remettre l'opacité à 100% de l'élément ayant lancé l'évènement (variable globale)
 *      2. Mettre à jour l'attribut opacity de l'élément correspondant
 *
 * Astuce : on peut concaténer un nombre avec une chaîne de caractères (même vide)
 *          pour obtenir une chaîne de caractères
 */
function reapparaitreMechant1() {

    // ÉCRIRE VOTRE CODE ICI

}
function reapparaitreMechant2() {

    // ÉCRIRE VOTRE CODE ICI

}
function reapparaitreMechant3() {

    // ÉCRIRE VOTRE CODE ICI

}
//endregion
