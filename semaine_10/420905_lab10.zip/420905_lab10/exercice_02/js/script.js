// VARIABLES GLOBALES (Aucune)

/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    document.getElementById("bouton1").addEventListener("click", bouton1);
    document.getElementById("bouton2").addEventListener("click", bouton2);
    document.getElementById("reset").addEventListener("click", reset);
}

/* TODO 2
*  À faire :
*  1 - Dans une boucle dont l'index parcourt les nombres de 1 à 16 (inclus)
*  2 -      Si l'index est pair (multiple de 2, utilisez modulo %)
*  3 -          Pour l'élément avec l'id "nourriture[index]", où [index] est
*               l'index actuel, changer le style (propriété borderColor) pour
*               appliquer une bordure verte. ("limegreen")
 */
function bouton1(){

    // ÉCRIRE VOTRE CODE ICI

}

/* TODO 3
*  À faire :
*  1 - Dans une boucle dont l'index parcourt les nombres de 1 à 16 (inclus)
*  2 -      Si l'index est un multiple de 4 (utilisez modulo %)
*  3 -          Pour l'élément avec l'id "nourriture[index]", où [index] est
*               l'index actuel, changer le style (propriété borderColor) pour
*               appliquer une bordure rouge. ("crimson")
 */
function bouton2(){

    // ÉCRIRE VOTRE CODE ICI

}

// Ne pas modifier le code à partir d'ici

function reset(){
    for(let index = 1; index < 17; index++){
        document.getElementById("nourriture" + index).style.borderColor = "black";
    }
}