//DÉCLARATION DES VARIABLES GLOBALES (ACCESSIBLES PARTOUT)
let gTableauItems = ["Champignon"];
let gChampiAleatoire;


//region TODO 01 : fonction init() - NE RIEN MODIFIER, SEULEMENT REGARDER
/**
 * Description : Cette fonction prépare la page
 */
function init() {
    document.getElementById("boutonAjouter").addEventListener("click", ajouterItem);
    document.getElementById("boutonRetirer").addEventListener("click", retirerDernier);
    mettreAJour();
}
//endregion


//region TODO 02 : fonction ajouterItem()
/**
 * Description : Fonction appelée lors du clic sur le bouton Ajouter
 * 
 * Algorithme : 1. S'il y a plus que 5 éléments dans le tableau ( la longueur du tableau est supérieure ou égale à 5 )
 *						2. Faire une alerte au joueur avec le message suivant : "Vous avez déjà atteint de maximum d'item"
 *				3. Sinon
 *						4. Ajouter le contenu de la variable gChampiAleatoire à la fin du tableau des items
 *					    5. Appeler la fonction pour mettre à jour le nombre d'items
 * 
 */
function ajouterItem() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 03 : fonction mettreAJourNombreDesItems()
/**
 * Description : Met à jour le nombre d'item sur la page
 *
 * Algorithme :  1. Modifier le texte de l'élément avec le id "texteNombreItems" afin d'afficher
 *                  "Nombre d'items : [longueur]" où [longueur] est la longueur du tableau des items
 *               2. Appeler la fonction afficherTableau
 */
function mettreAJour() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region TODO 04 : fonction retirerDernier()
/**
 * Description : Fonction appelée lors du clic sur le bouton RetirerDernier
 * 
 * Algorithme : 1. Si le tableau est vide ( la longueur du tableau est égale à 0 )
 *						2. Faire une alerte avec le message suivant : "Il n'y a plus d'items à retirer"
 *				3. Sinon
 *						4. Déclarer une variable appelée item et l'instancier avec le dernier élément du tableau que l'on retire
 *					    5. Faire une alerte avec le contenu suivant : "Item retiré : [item]" où [item] est la variable item
 *						5. Appeler la fonction pour mettre à jour le nombre d'items
 * 
 */
function retirerDernier() {
    // Écrire le code ci-dessous


    // ECRIRE DU CODE ICI


}
//endregion


//region CODE À NE PAS MODIFIER
function afficherTableau() {
    switch (Math.floor(Math.random() * (2 - 1 + 1)) + 1){
        case 1 :
            gChampiAleatoire = "Champignon";
            break;
        case 2 :
            gChampiAleatoire = "ChampignonMechant";
            break;
    }
    for (var index = 0; index < 5; index++) {
        document.getElementById("item" + (index + 1)).setAttribute("src","images/vide.png");
    }

    for (var index = 0; index < gTableauItems.length; index++) {
        if (gTableauItems[index] == "Champignon"){
            document.getElementById("item" + (index + 1)).setAttribute("src","images/champignon.png");
        } else {
            document.getElementById("item" + (index + 1)).setAttribute("src","images/champignonMechant.png");
        }
    }
}
//endregion