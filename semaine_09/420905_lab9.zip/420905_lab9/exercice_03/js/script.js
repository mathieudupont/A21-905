// VARIABLES GLOBALES
let gIdsArticles = ["diachylon", "maquillage", "papierToilette", "pillule", "seringue"]; // Tableau contenant les ids des articles
let gPrix = 0;          // Nombre entier pour le prix d'un article
let gQuantite = 0;      // Nombre entier pour la quantité d'un article
let gValeurTotale = 0;  // Nombre entier pour la somme des articles dans l'inventaire
let gId = "";           // id de l'élément sélectionné


/* TODO 1 (Rien à faire)
*  init() : Création des écouteurs d'événements
*/
function init(){
    for(let index = 0; index < gIdsArticles.length; index++){
        document.getElementById(gIdsArticles[index]).addEventListener("click", selectionnerArticle);
    }
}


/* TODO 2
*  À faire :
*
*  1 - Obtenir la valeur de l'attribut "data-prix" pour 
*      l'élément ciblé et l'affecter à la variable gPrix.
*
*  !! Attention, vous ne devez pas créer la variable gPrix.
*             Elle existe déjà.
*
*  2 - Obtenir la valeur de l'attribut "data-quantite" pour 
*      l'élément ciblé et l'affecter à la variable gQuantite.
*
*  3 - Multiplier gQuantite et gPrix et affecter ce résultat à
*      la variable gValeurTotale. ATTENTION : Vous aurez à faire
*      des conversions pour cette opération :
*           - gPrix : Convertir Chaîne de caractères -> Nombre décimal
*           - gQuantite : Convertir Chaîne de caractères -> Nombre entier
*
*  4 - Obtenir la valeur de l'attribut "id" pour 
*      l'élément ciblé et l'affecter à la variable gId.
*
*  5 - Appeler la fonction afficherInfo. Elle ne prend aucun paramètre.
*/ 
function selectionnerArticle(){

    // ECRIRE DU CODE ICI



}


//region NE PAS MODIFIER CETTE FONCTION. Elle affiche les infos de l'article sélectionné.
function afficherInfo(){

    for(let index = 0; index < gIdsArticles.length; index++){
        if(gIdsArticles[index] == gId){
            document.getElementById(gIdsArticles[index]).style.backgroundColor = "pink";
        }
        else{
            document.getElementById(gIdsArticles[index]).style.backgroundColor = "white";
        }
    }
    document.getElementById("prix").textContent = gPrix;
    document.getElementById("quantite").textContent = gQuantite;
    document.getElementById("valeurTotale").textContent = gValeurTotale.toFixed(2);

}
//endregion