// Classe Grenouille.
/* Propriétés :
*  satiete : Représente la faim
*  hydratation : Représente la soif
*  energie : Représente l'énergie
*
*/
class Grenouille{
    constructor(satiete, hydratation, energie){
        this.satiete = satiete;
        this.hydratation = hydratation;
        this.energie = energie;
    }
}