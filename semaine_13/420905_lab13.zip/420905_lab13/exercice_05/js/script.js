/* Mise en situation
* Vous avez envoyé votre travail à Mark Zuckerberg qui l'a montré à sa grand-mère Jeannine.
* Il est revenu vous voir furieux !
* Il dit que sa grand-mère a réussi à hacker le système en obtenant un nombre négatif de pièces...
* Comment pouvez-vous arranger le problème?
 */

// VARIABLES GLOBALES


// ECRIRE DU CODE ICI



/* TODO 1 : init */
function init(){



    // ECRIRE DU CODE ICI


}

/* TODO 2 : augmenter */
function augmenter(){



    // ECRIRE DU CODE ICI



}

/* TODO 3 : reduire */
function reduire(){



    // ECRIRE DU CODE ICI



}


