//region TODO 01 : Regarder la fonction init (CONSULTATION SEULEMENT)
/**
 * Fonction principale de l'application.
 * Elle est appelée immédiatement après la fin du chargement du document HTML.
 */
function init() {
    //RIEN NE DOIT ÊTRE MODIFIÉ DANS CETTE FONCTION, VOUS POUVEZ PASSER AU TODO SUIVANT
    //Lier les évènements souhaités des objets aux fonctions a exécuter
    document.getElementById("mot1").addEventListener("mouseover", ajouterMot1);
    document.getElementById("mot2").addEventListener("mouseover", ajouterMot2);
    document.getElementById("mot3").addEventListener("mouseover", ajouterMot3);
    document.getElementById("mot4").addEventListener("mouseover", ajouterMot4);
}
//endregion


//region TODO 02 : Compléter la fonction ajouterMot1()
/**
 * Description : Cette fonction s'exécute suite à un événement 'mouseover'.
 *
 * Algorithme :
 *
 *      1. Ajouter à la phrase le texte du premier mot
 *      2. Rendre le mot invisible
 *
 *  Pour vous aider :
 *  Quel élément doit être modifié?
 *  Quelle propriété de cet élément on veut changer?
 *  Quelle valeur doit être ajoutée?
 *
 *  1. Concaténer à la propriété textContent de l'élément "phrase" la valeur de la propriété textContent de l'objet "mot1"
 *  2. Assigner à la propriété display de l'élément "mot1" la valeur "none"
 */

function ajouterMot1() {
    // ÉCRIRE VOTRE CODE ICI
}
//endregion


//region TODO 03 : Compléter la fonction ajouterMot2()
/**
 * Description : Cette fonction s'exécute suite à un évènement 'mouseover'.
 *
 * Algorithme :
 *
 *      1. Ajouter à la phrase le texte du deuxième mot
 *      2. Rendre le mot invisible
 */
function ajouterMot2() {
    // ÉCRIRE VOTRE CODE ICI
}
//endregion


//region TODO 04 : Compléter la fonction ajouterMot3()
/**
 * Description : Cette fonction s'exécute suite à un évènement 'mouseover'.
 *
 * Algorithme :
 *
 *      1. Ajouter à la phrase le texte du troisième mot
 *      2. Rendre le mot invisible
 */
function ajouterMot3() {
    // ÉCRIRE VOTRE CODE ICI
}
//endregion


//region TODO 05 : Compléter la fonction ajouterMot4()
/**
 * Description : Cette fonction s'exécute suite à un évènement 'mouseover'.
 *
 * Algorithme :
 *
 *      1. Ajouter à la phrase le texte du quatrième mot
 *      2. Rendre le mot invisible
 */
function ajouterMot4() {
    // ÉCRIRE VOTRE CODE ICI
}
//endregion
