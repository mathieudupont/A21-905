
/* TODO 1 : Rien à faire ici */
function init() {
    document.getElementById("bouton1").addEventListener('click', echec);
    document.getElementById("bouton2").addEventListener('click', echec);
    document.getElementById("bouton3").addEventListener('click', succes);
    document.getElementById("bouton4").addEventListener('click', echec);
}


/* TODO 2 : fonction afficherResultat
    À faire :
        1 - Déclarer une variable nommée element et lui affecter l'élément avec l'ID "reponse"
        2 - Si reussite est égale à true
        3 -     Remplacer le contenu textuel de l'élément element par la valeur "Exact!"
        4 -     Donner à la propriété de style backgroundColor de l'élément element la valeur "green"
        5 - Sinon
        6 -     Remplacer le contenu textuel de l'élément element par la valeur "Meilleure chance la prochaine fois!"
        7 -     Modifier la couleur de fond de l'élément element pour "red"
 */
function afficherResultat(reussite) {


// ECRIRE DU CODE ICI


}


/* TODO 3 : fonction echec
    À faire :
        1 - Appeler la fonction afficherResultat en lui passant comme paramètre la valeur false
 */
function echec() {


// ECRIRE DU CODE ICI


}


/* TODO 4 : fonction succes
    À faire :
        1 - Appeler la fonction afficherResultat en lui passant comme paramètre la valeur true
 */
function succes() {


// ECRIRE DU CODE ICI


}