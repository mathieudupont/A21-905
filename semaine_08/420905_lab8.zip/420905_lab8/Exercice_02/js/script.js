
/* TODO 1 : Déclarer les variables globales
    À faire :
        1 - Déclarer la variable globale gCompteur et l'instancier à la valeur 0
*/


// ECRIRE DU CODE ICI




/* TODO 2 : Rien à faire ici */
function init() {
    document.getElementById("plus1").addEventListener('click', compteurPlus1);
    document.getElementById("plus2").addEventListener('click', compteurPlus2);
    document.getElementById("moins1").addEventListener('click', compteurMoins1);
    document.getElementById("moins2").addEventListener('click', compteurMoins2);
}


/* TODO 3 : fonction modifierCompteur
    À faire :
        1 - Ajouter à gCompteur la valeur de step
        2 - Remplacer le contenu textuel de l'élément avec l'ID "compteurId" par la valeur de gCompteur
 */
function modifierCompteur(step) {


// ECRIRE DU CODE ICI


}


/* TODO 4 : fonction compteurPlus1
    À faire :
        1 - Appeler la fonction modifierCompteur en lui passant comme paramètre la valeur 1
 */
function compteurPlus1() {


// ECRIRE DU CODE ICI


}


/* TODO 5 : fonction compteurPlus2
    À faire :
        1 - Appeler la fonction modifierCompteur en lui passant comme paramètre la valeur 2
 */
function compteurPlus2() {


// ECRIRE DU CODE ICI


}


/* TODO 6 : fonction compteurMoins1
    À faire :
        1 - Appeler la fonction modifierCompteur en lui passant comme paramètre la valeur -1
 */
function compteurMoins1() {


// ECRIRE DU CODE ICI


}


/* TODO 7 : fonction compteurMoins2
    À faire :
        1 - Appeler la fonction modifierCompteur en lui passant comme paramètre la valeur -2
 */
function compteurMoins2() {


// ECRIRE DU CODE ICI


}