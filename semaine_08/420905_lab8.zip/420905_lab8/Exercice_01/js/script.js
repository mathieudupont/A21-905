
/* TODO 1 : Rien à faire ici */
function init() {
    document.getElementById("lumiereOn").addEventListener("click", eteindreLumiere);
    document.getElementById("lumiereOff").addEventListener("click", allumeLumiere);
}


/* TODO 2 : fonction allumeLumiere
    À faire :
        1 - Donner à la propriété de style display de l'élément avec l'ID "lumiereOff" la valeur "none"
        2 - Donner à la propriété de style display de l'élément avec l'ID "lumiereOn" la valeur "block"
 */
function allumeLumiere() {


// ECRIRE DU CODE ICI


}


/* TODO 3 : fonction eteindreLumiere
    À faire :
        1 - Donner à la propriété de style display de l'élément avec l'ID "lumiereOn" la valeur "none"
        2 - Donner à la propriété de style display de l'élément avec l'ID "lumiereOff" la valeur "block"
 */
function eteindreLumiere() {


// ECRIRE DU CODE ICI


}